/* LEC Assistant. Works on its own from the site's own content, no server needed.
   Optional: set CONFIG.aiEndpoint to a proxy that talks to a real AI model (see worker/ai-proxy.js).
   The assistant never gives financial or legal advice and never promises income. */
(function () {
  "use strict";
  var doc = document;
  var C = window.CONFIG || {};
  var digits = String(C.adminNumber || "").replace(/\D/g, "");
  var wa = function (k) { return { main: C.whatsappMain, starters: C.whatsappStarters, builders: C.whatsappBuilders, earners: C.whatsappEarners }[k]; };
  var adminUrl = function (t) { return "https://wa.me/" + digits + (t ? "?text=" + encodeURIComponent(t) : ""); };

  var ic = function (n) { return '<svg class="icon" aria-hidden="true"><use href="#i-' + n + '"/></svg>'; };

  /* ---------- Knowledge base (answers come only from what the site says) ---------- */
  var KB = [
    { id: "hi", k: ["hi", "hello", "hey", "good morning", "good evening", "good afternoon", "how far", "howdy", "sup", "wassup"], a: "Hello! I am the LEC Assistant. I can explain how LEC works, help you pick a path, and point you to the right page. What would you like to know?", q: ["What is LEC?", "Find my path", "Is it free?", "How do I get paid?"] },
    { id: "what", k: ["what is lec", "about lec", "learn and earn circle", "what is this", "what do you do", "who are you", "explain lec", "wetin be lec", "wetin be this"], a: "LEC, the Learn & Earn Circle, is a free community for Africans, starting with Nigeria, who want to learn tech and digital skills and turn them into income in naira or dollars. It starts on WhatsApp, and Telegram comes later.\n\nThe ladder is simple: Learn, Build, Earn. See [how it works](index.html#how).", q: ["Find my path", "Is it free?", "Is this a scam?"] },
    { id: "free", k: ["free", "cost", "pay to join", "charge", "price to join", "fee to join", "subscription", "how much to join", "money to join", "na free"], a: "Yes, joining LEC is free and we will never charge you to enter. Some courses or tools you choose outside LEC may have their own costs, and we will always be clear about that.", q: ["Is this a scam?", "How do I join?"] },
    { id: "scam", k: ["scam", "legit", "legitimate", "fraud", "trust", "real or fake", "419", "yahoo", "safe to join", "can i trust"], a: "No. We do not ask for money to join, we never ask for bank details or passwords, and we do not promise income. If anyone using the LEC name asks you for money, please report it to the admins.\n\nRead [what we will never do](index.html#never) and the [scam red flags](toolkit.html#safe).", q: ["Report a scam", "How do I join?"] },
    { id: "join", k: ["join", "how to join", "enter", "register", "sign up", "signup", "get in", "link", "group link", "whatsapp group", "add me", "i wan join", "how do i join"], a: "Joining takes under a minute. Pick the group that fits you, or take the 3 question level finder and I will point you to the right one.", act: "join", q: ["Find my path", "Telegram?"] },
    { id: "path", k: ["path", "level", "which group", "where do i start", "where should i start", "start", "beginner", "which one", "recommend", "find my path"], a: "LEC has three subgroups:\n• Starters: beginners learning a first skill\n• Builders: people with a skill who need a portfolio and proof\n• Earners: people ready to find clients, price work, and get paid\n\nSee [all three paths](paths.html), or I can ask you 3 quick questions.", q: ["Find my path"] },
    { id: "starters", k: ["starters", "no skill", "dont have a skill", "do not have a skill", "zero", "i know nothing", "first skill", "never coded", "new to tech"], a: "LEC Starters is made for you. You pick one skill, practise it with others who are starting too, and finish a first practice project. See the [Starters path](paths.html#starters).", act: "starters" },
    { id: "builders", k: ["builders", "portfolio", "proof", "case study", "profile", "show my work"], a: "LEC Builders helps you turn what you can do into a portfolio and a profile clients can trust, with reviews from people at your level and above. See the [Builders path](paths.html#builders).", act: "builders" },
    { id: "earners", k: ["earners", "clients", "find clients", "first client", "pitch", "proposal", "get clients", "customers"], a: "LEC Earners covers pitch practice, pricing, proposals, agreements, and getting paid safely. Start with the [first client guide](toolkit.html#client), which has message templates you can copy.", act: "earners" },
    { id: "skills", k: ["skills", "which skill", "what skill", "courses", "what can i learn", "web design", "video editing", "graphic", "copywriting", "marketing", "virtual assistant", "no code", "ai tools", "data", "spreadsheet"], a: "We cover web design, AI tools and automation, video editing, graphic design, content and copywriting, digital marketing, virtual assistance, spreadsheets and data, and no code apps. Not sure which fits? Ask in Starters, and members will help you choose one skill to begin with.", q: ["Find my path", "Do I need a laptop?"] },
    { id: "laptop", k: ["laptop", "phone", "computer", "device", "data", "mobile", "android", "do i need"], a: "Not to start. You can begin learning, planning, and practising on a phone. A laptop helps for skills like web design and video editing, and you can plan for one as you grow.", q: ["Find my path", "Which skills?"] },
    { id: "paid", k: ["get paid", "payment", "receive money", "receive payment", "withdraw", "how to be paid", "collect money", "paid", "dollar", "naira", "payoneer", "grey", "raenest", "cleva", "wise", "paystack", "flutterwave", "selar", "bank transfer", "invoice"], a: "Our Get Paid Toolkit covers both lanes:\n• [Local, in naira](toolkit.html#local): bank transfer, Paystack and Flutterwave links, Selar\n• [International, in dollars](toolkit.html#international): Payoneer, Grey, Raenest, Cleva, Wise\n\nWe list them in no order of preference and we do not state fees. Rules change, so always check each provider's current terms. This is information, not financial advice.", q: ["Price calculator", "Templates", "Is this a scam?"] },
    { id: "price", k: ["price", "pricing", "rate", "how much should i charge", "charge clients", "hourly", "calculator", "what to charge", "quote"], a: "Use the [rate calculator](toolkit.html#price). Enter your monthly target, weekly hours, and billable share, and it gives you a minimum hourly rate in naira and dollars. It is a floor, not a target, so add room for tax, tools, and slow months.", q: ["Templates", "How do I get paid?"] },
    { id: "templates", k: ["template", "templates", "message", "proposal template", "what do i send", "script", "follow up", "agreement", "invoice template"], a: "The [toolkit templates](toolkit.html#templates) include a proposal, invoice basics, an agreement checklist, and a follow up message. The [first client section](toolkit.html#client) has local, online, and referral messages. Each has a copy button.", q: ["Price calculator"] },
    { id: "income", k: ["how much will i earn", "how much can i earn", "salary", "guarantee", "make money fast", "get rich", "earn how much", "promise", "income", "how long", "how soon", "rich"], a: "We cannot promise income, and nobody honest can. Results depend on your skill, time, and effort. What we can promise is honest guidance, real practice, and people who want to see you get paid. A realistic first 30 days is: pick a skill, finish a practice project, build a portfolio, then pitch your first client. See [your first 30 days](index.html#blueprint).", q: ["Find my path", "Is this a scam?"] },
    { id: "telegram", k: ["telegram", "tg"], a: "WhatsApp now, Telegram later. It is the same community, so use the app you prefer once Telegram opens. Telegram is coming soon.", q: ["How do I join?"] },
    { id: "rules", k: ["rules", "allowed", "not allowed", "can i post", "promote", "advertise", "crypto", "investment", "forex", "spam"], a: "A few simple rules: respect everyone, no spam, no investment or crypto pitches, no pay to join schemes, never share personal or financial data, share wins and lessons, and no hate or harassment. See all of them on the [Join page](join.html#rules).", q: ["How do I join?"] },
    { id: "wins", k: ["wins", "testimonial", "success stories", "results", "proof members", "members earning"], a: "The Wins Wall is empty for now, on purpose. We only show real wins from real members, shared with their permission, and we would rather show nothing than invent anything. Members can submit a win to the admin.", act: "winmsg" },
    { id: "founder", k: ["founder", "who started", "who owns", "who runs", "team", "admin", "who is behind"], a: "LEC is run by volunteers who want to see more Africans get paid for their skills. You can message an admin directly on WhatsApp.", act: "admin" },
    { id: "contact", k: ["contact", "email", "talk to someone", "human", "speak to", "support", "help me", "reach", "phone number", "call"], a: "You can reach a real person here:", act: "admin" },
    { id: "who", k: ["who is it for", "students", "who can join", "age", "country", "africa", "ghana", "kenya", "south africa", "outside nigeria", "other countries"], a: "LEC is for Africans who want to learn tech and digital skills and earn from them. We start with Nigeria, and members from other African countries are welcome as the circle grows." },
    { id: "thanks", k: ["thanks", "thank you", "thank", "nice", "great", "cool", "okay", "ok", "good", "abeg thanks", "weldone", "well done"], a: "You are welcome! If you want to take the next step, joining the circle is free.", q: ["How do I join?", "Find my path"] },
    { id: "bye", k: ["bye", "goodbye", "see you", "later"], a: "Take care, and all the best with your learning. The circle is here when you are ready." }
  ];

  var QUICK = {
    "What is LEC?": "what is lec", "Is it free?": "is it free", "Find my path": "__quiz", "How do I get paid?": "how do i get paid",
    "Is this a scam?": "is this a scam", "How do I join?": "how do i join", "Telegram?": "telegram", "Do I need a laptop?": "do i need a laptop",
    "Price calculator": "price calculator", "Templates": "templates", "Which skills?": "which skills", "Report a scam": "__scam"
  };

  var STOP = /\b(the|a|an|is|are|to|of|and|in|on|for|me|my|i|do|you|it|can|how|what|am|be)\b/g;
  function norm(s) { return " " + s.toLowerCase().replace(/[^a-z0-9 ]+/g, " ").replace(/\s+/g, " ").trim() + " "; }
  function score(text, entry) {
    var n = norm(text), s = 0;
    entry.k.forEach(function (kw) {
      var p = " " + kw + " ";
      if (n.indexOf(p) > -1) { s += kw.indexOf(" ") > -1 ? 4 : 2; }
      else if (kw.length > 4 && n.indexOf(" " + kw.slice(0, -1)) > -1) { s += 1; }
    });
    return s;
  }
  function best(text) {
    var top = null, ts = 0, second = 0;
    KB.forEach(function (e) {
      var s = score(text, e);
      if (s > ts) { second = ts; ts = s; top = e; } else if (s > second) { second = s; }
    });
    return ts >= 2 ? top : null;
  }

  /* ---------- UI ---------- */
  var launch, panel, log, form, input, open = false, history = [], quizState = null;

  function build() {
    launch = doc.createElement("button");
    launch.className = "chat-launch"; launch.type = "button";
    launch.setAttribute("aria-label", "Open LEC Assistant"); launch.setAttribute("aria-expanded", "false");
    launch.innerHTML = '<span class="spark">' + ic("spark") + '</span><span>Ask LEC</span>';
    panel = doc.createElement("section");
    panel.className = "chat"; panel.setAttribute("role", "dialog"); panel.setAttribute("aria-label", "LEC Assistant");
    panel.innerHTML =
      '<div class="chat-head"><span class="av">' + ic("spark") + '</span><div><b>LEC Assistant</b><small><span class="dot"></span> Answers from this site</small></div><button type="button" class="x" aria-label="Close chat">' + ic("x") + '</button></div>' +
      '<div class="chat-log" role="log" aria-live="polite" tabindex="0"></div>' +
      '<form class="chat-form" autocomplete="off"><label class="sr" for="chat-in" style="position:absolute;left:-999px">Your question</label><input id="chat-in" type="text" placeholder="Ask about LEC, paths, getting paid" maxlength="300"><button type="submit" aria-label="Send">' + ic("send") + '</button></form>' +
      '<p class="chat-note">I can make mistakes. Not financial or legal advice. Never share passwords or bank details.</p>';
    doc.body.appendChild(launch); doc.body.appendChild(panel);
    log = panel.querySelector(".chat-log"); form = panel.querySelector("form"); input = panel.querySelector("input");
    launch.addEventListener("click", function () { toggle(true); });
    panel.querySelector(".x").addEventListener("click", function () { toggle(false); });
    doc.addEventListener("keydown", function (e) { if (e.key === "Escape" && open) { toggle(false); } });
    form.addEventListener("submit", function (e) { e.preventDefault(); var v = input.value.trim(); if (v) { input.value = ""; ask(v); } });
    // allow any button on the page to open the assistant
    Array.prototype.forEach.call(doc.querySelectorAll("[data-open-chat]"), function (b) { b.addEventListener("click", function (e) { e.preventDefault(); toggle(true); }); });
    restore();
  }

  function toggle(v) {
    open = v;
    panel.classList.toggle("open", v); launch.classList.toggle("hide", v);
    launch.setAttribute("aria-expanded", v ? "true" : "false");
    if (v) {
      if (!log.children.length) { greet(); }
      setTimeout(function () { input.focus(); log.scrollTop = log.scrollHeight; }, 250);
    } else { launch.focus(); }
  }

  /* Tiny safe markup: [label](url) links and lines that start with a bullet */
  function render(el, text) {
    var lines = text.split("\n"), ul = null;
    lines.forEach(function (ln, i) {
      var holder = el;
      if (ln.indexOf("• ") === 0) {
        if (!ul) { ul = doc.createElement("ul"); el.appendChild(ul); }
        var li = doc.createElement("li"); ul.appendChild(li); holder = li; ln = ln.slice(2);
      } else {
        ul = null;
        if (i > 0 && ln === "") { el.appendChild(doc.createElement("br")); return; }
        if (i > 0 && el.lastChild && el.lastChild.nodeName !== "BR" && el.lastChild.nodeName !== "UL") { el.appendChild(doc.createElement("br")); }
      }
      var re = /\[([^\]]+)\]\(([^)]+)\)/g, last = 0, m;
      while ((m = re.exec(ln))) {
        holder.appendChild(doc.createTextNode(ln.slice(last, m.index)));
        var a = doc.createElement("a"); a.href = m[2]; a.textContent = m[1];
        if (/^https?:/.test(m[2])) { a.target = "_blank"; a.rel = "noopener"; }
        holder.appendChild(a); last = re.lastIndex;
      }
      holder.appendChild(doc.createTextNode(ln.slice(last)));
    });
  }

  function say(who, text, save) {
    var d = doc.createElement("div"); d.className = "msg " + who;
    if (who === "me") { d.textContent = text; } else { render(d, text); }
    log.appendChild(d); log.scrollTop = log.scrollHeight;
    if (save !== false) { history.push({ w: who, t: text }); persist(); }
    return d;
  }
  function chips(items) {
    var w = doc.createElement("div"); w.className = "quick";
    items.forEach(function (it) {
      var el;
      if (it.href) { el = doc.createElement("a"); el.href = it.href; if (/^https?:/.test(it.href)) { el.target = "_blank"; el.rel = "noopener"; } if (it.go) { el.className = "go"; } }
      else { el = doc.createElement("button"); el.type = "button"; el.addEventListener("click", function () { w.remove(); if (it.fn) { it.fn(); } else { say("me", it.label); respond(it.val || it.label); } }); }
      el.textContent = it.label; w.appendChild(el);
    });
    log.appendChild(w); log.scrollTop = log.scrollHeight;
  }
  function typing(cb, ms) {
    var d = doc.createElement("div"); d.className = "msg bot";
    d.innerHTML = '<span class="typing" aria-label="Typing"><i></i><i></i><i></i></span>';
    log.appendChild(d); log.scrollTop = log.scrollHeight;
    setTimeout(function () { d.remove(); cb(); }, ms || 450);
  }

  function greet() {
    say("bot", "Hi, I am the LEC Assistant. Ask me anything about the community, the paths, or getting paid. I answer from what this site says, and I will point you to a real admin when I cannot help.");
    chips(["What is LEC?", "Find my path", "Is it free?", "How do I get paid?"].map(function (l) { return { label: l }; }));
  }

  function groupChips() {
    chips([
      { label: "Join Starters", href: wa("starters"), go: true }, { label: "Join Builders", href: wa("builders"), go: true },
      { label: "Join Earners", href: wa("earners"), go: true }, { label: "Main community", href: wa("main") }
    ]);
  }

  /* 3 question level finder inside the chat (same logic as the Join page) */
  function startQuiz() {
    quizState = {};
    say("bot", "Three quick questions. First: do you have a skill you can show?");
    chips([{ label: "Yes, I can show my work", fn: function () { qa("skill", "yes", "Yes, I can show my work"); } }, { label: "A little", fn: function () { qa("skill", "little", "A little, still learning"); } }, { label: "Not yet", fn: function () { qa("skill", "no", "No, not yet"); } }]);
  }
  function qa(key, val, label) {
    quizState[key] = val; say("me", label);
    if (key === "skill") {
      typing(function () {
        say("bot", "Have you been paid for it?");
        chips([{ label: "Yes", fn: function () { qa("paid", "yes", "Yes, more than once"); } }, { label: "Once or twice", fn: function () { qa("paid", "once", "Once or twice"); } }, { label: "Not yet", fn: function () { qa("paid", "no", "Not yet"); } }]);
      }, 300);
    } else if (key === "paid") {
      typing(function () {
        say("bot", "What do you need most right now?");
        chips([{ label: "To learn a skill", fn: function () { qa("need", "learn", "To learn a skill"); } }, { label: "Portfolio and proof", fn: function () { qa("need", "portfolio", "A portfolio and proof"); } }, { label: "Clients and getting paid", fn: function () { qa("need", "clients", "Clients, pricing, getting paid"); } }]);
      }, 300);
    } else {
      var s = quizState, level;
      if (s.skill === "no" || s.need === "learn") { level = "starters"; }
      else if (s.need === "portfolio") { level = "builders"; }
      else if (s.skill === "little" && s.paid === "no") { level = "builders"; }
      else { level = "earners"; }
      var nm = { starters: "LEC Starters", builders: "LEC Builders", earners: "LEC Earners" }[level];
      var why = { starters: "You are at the start, and that is a good place to be. Starters helps you pick one skill and finish a first practice project.", builders: "You have something to build on. Builders helps you turn it into a portfolio and proof that clients can trust.", earners: "You are ready for clients. Earners helps you find them, price your work, and get paid properly." }[level];
      quizState = null;
      typing(function () {
        say("bot", "Your path: " + nm + ".\n" + why);
        chips([{ label: "Join " + nm, href: wa(level), go: true }, { label: "Read about it", href: "paths.html#" + level }]);
      }, 450);
    }
  }

  function respond(text) {
    if (text === "__quiz" || /\b(find my path|level finder|which level|which group|take the quiz)\b/i.test(text)) { startQuiz(); return; }
    if (text === "__scam") { say("bot", "Thank you for reporting. Message an admin with screenshots, and also report it on the platform where it happened."); chips([{ label: "Message admin", href: adminUrl("Hi LEC admin, I want to report a scam."), go: true }, { label: "Email", href: "mailto:" + C.email + "?subject=Scam%20report" }]); return; }
    var mapped = QUICK[text] || text;
    var go = function (reply) {
      typing(function () {
        if (reply.e) {
          say("bot", reply.e.a);
          var a = reply.e.act;
          if (a === "join") { groupChips(); }
          else if (a === "starters" || a === "builders" || a === "earners") { chips([{ label: "Join " + a.charAt(0).toUpperCase() + a.slice(1), href: wa(a), go: true }]); }
          else if (a === "admin") { chips([{ label: "Message admin on WhatsApp", href: adminUrl("Hi LEC admin"), go: true }, { label: "Email", href: "mailto:" + C.email }]); }
          else if (a === "winmsg") { chips([{ label: "Submit a win", href: adminUrl("Hi LEC admin, I would like to submit a win."), go: true }]); }
          if (reply.e.q) { chips(reply.e.q.map(function (l) { return { label: l }; })); }
        } else if (reply.ai) {
          say("bot", reply.ai);
          chips([{ label: "Talk to an admin", href: adminUrl("Hi LEC admin"), go: true }]);
        } else {
          say("bot", "I am not sure I have a good answer for that, and I would rather not guess. Try one of these, or message an admin who can help properly.");
          chips([{ label: "What is LEC?" }, { label: "Find my path" }, { label: "How do I get paid?" }, { label: "Talk to an admin", href: adminUrl("Hi LEC admin, I have a question: " + text.slice(0, 120)), go: true }]);
        }
      }, 500);
    };
    var hit = best(mapped);
    if (hit) { go({ e: hit }); return; }
    if (C.aiEndpoint) {
      aiAsk(text).then(function (r) { go(r ? { ai: r } : {}); }, function () { go({}); });
    } else { go({}); }
  }

  function aiAsk(text) {
    var ctrl = window.AbortController ? new AbortController() : null;
    var t = setTimeout(function () { if (ctrl) { ctrl.abort(); } }, 9000);
    return fetch(C.aiEndpoint, { method: "POST", headers: { "Content-Type": "application/json" }, signal: ctrl ? ctrl.signal : undefined, body: JSON.stringify({ message: text, history: history.slice(-8) }) })
      .then(function (r) { clearTimeout(t); return r.ok ? r.json() : null; })
      .then(function (j) { return j && typeof j.reply === "string" ? j.reply.slice(0, 900) : null; });
  }

  function ask(text) {
    // open the admin or a page directly when asked by link words
    say("me", text);
    respond(text);
  }

  /* Remember the conversation for this tab only */
  function persist() { try { sessionStorage.setItem("lec-chat", JSON.stringify(history.slice(-30))); } catch (e) { /* ignore */ } }
  function restore() {
    try {
      var h = JSON.parse(sessionStorage.getItem("lec-chat") || "[]");
      if (h.length) { h.forEach(function (m) { say(m.w, m.t, false); }); history = h; }
    } catch (e) { /* ignore */ }
  }

  function boot() { try { build(); } catch (e) { /* chat is optional */ } }
  if ("requestIdleCallback" in window) { requestIdleCallback(boot, { timeout: 1500 }); } else { setTimeout(boot, 600); }
})();
