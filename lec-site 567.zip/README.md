# LEC, Learn & Earn Circle website (merged build)

Plain HTML, CSS and JavaScript. No frameworks. Upload the whole folder to any static host
(Netlify, Vercel, Cloudflare Pages, GitHub Pages, cPanel). It needs HTTPS for the install and offline features.

Files: index.html, paths.html, toolkit.html, join.html, styles.css, main.js (settings, forms, calculator, quiz),
fx.js (animated background and motion), chat.js (LEC Assistant), sw.js and manifest.webmanifest (installable, works offline),
assets/ (icons, share image), worker/ai-proxy.js (optional real AI), build.js (optional, regenerates the four pages: node build.js).

## What you must fill in

1. main.js, CONFIG at the top: the four WhatsApp invite links, adminNumber (digits only, for example 234801234567), email, lastReviewed.
   handle is set to @lecircle. Check it is free on each platform before you print it anywhere.
   Leave telegramLink empty until Telegram is live.
2. The HTML files hold the same placeholders as a no JavaScript fallback. Easiest route: edit build.js (SITE, WA links, email, number) and run node build.js.
   Placeholders: REPLACE_MAIN, REPLACE_STARTERS, REPLACE_BUILDERS, REPLACE_EARNERS, 234XXXXXXXXXX, hello@example.com, https://example.com/
3. Home page founder note: [Founder name and role] and the optional proof line.
4. Footer social links use the handle for every platform. Change any that differ.
5. Domain: set SITE at the top of build.js, rebuild, and set your domain in worker/ai-proxy.js if you use it.
6. Toolkit: check each payment provider against its current terms before launch. The 1500 exchange rate in the calculator is an example.

## The assistant (chatbot)

Out of the box it answers from the site's own content (about 25 topics, plain English and some Naija phrases), runs the 3 question level finder,
and hands over to a real admin on WhatsApp. It needs no server and costs nothing.
To make it a real AI model: deploy worker/ai-proxy.js as a Cloudflare Worker, add your key as the secret ANTHROPIC_API_KEY,
and put the Worker URL in CONFIG.aiEndpoint. The key must never go in the website files. Local answers still come first, and the AI only answers what the built in answers cannot.

## Images

The site now uses five real photos found through Yandex Images (assets/photos/): hero, learn, build, earn and community, plus wide crops for the Paths page.
They are compressed WebP (lazy loaded below the first screen). Their original sources are third party stock and news sites, so sort out the
licences or replace them with licensed or your own photos before launch. To swap one, save a WebP with the same file name into assets/photos/ (hero 1200x900, learn, build and earn 800x600,
community 900x900, the three wide ones 1200x400) and the page picks it up. Alt text is set in build.js (the PH list).
The footer note and the Home page say photos are for illustration and show models, not LEC members. Keep that line unless the people are real members who agreed.

## Hero slider

Six slides with story style progress bars, arrows, swipe, a pause button and keyboard arrows. It pauses on hover, focus and when the tab is hidden, and stays still for visitors who prefer reduced motion or use Data Saver.
Slides are assets/photos/slide-1.webp to slide-6.webp (1200x900) with matching slide-N-sm.webp (640x480) for phones. Captions and alt text are in the SLIDES list in build.js.
To change the slide time, edit --dur in styles.css (.slider).

## Mobile package

lec-site-mobile.zip is the same site with small images only and no animated canvas background, for slow phones. The main build is already fully responsive, so use either one.

## Motion and data

Animated circuit background (pauses when the tab is hidden, switches off on Data Saver, slow connections and low memory phones), scroll reveals,
rotating skill word, light and dark mode, smooth page transitions. Everything respects "reduce motion".

## Test checklist

- [ ] 360 px wide: no sideways scrolling on all four pages
- [ ] Every WhatsApp, email and social link works after you fill CONFIG
- [ ] Level finder and assistant quiz open the right group
- [ ] Copy buttons, calculator and intro form work
- [ ] Turn JavaScript off: text, menu links and WhatsApp links still work
- [ ] Dark mode and light mode both read well
- [ ] Lighthouse mobile score 90 or above
- [ ] Read all copy once to confirm there are no promises of income
