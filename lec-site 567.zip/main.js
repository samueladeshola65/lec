/* LEC, Learn & Earn Circle. Edit CONFIG, then save. Nothing else needs changing. */
var CONFIG = {
  whatsappMain: "https://chat.whatsapp.com/REPLACE_MAIN",
  whatsappStarters: "https://chat.whatsapp.com/REPLACE_STARTERS",
  whatsappBuilders: "https://chat.whatsapp.com/REPLACE_BUILDERS",
  whatsappEarners: "https://chat.whatsapp.com/REPLACE_EARNERS",
  adminNumber: "234XXXXXXXXXX", // digits only, with country code, no plus sign
  email: "hello@example.com",
  telegramLink: "", // leave empty until Telegram is live
  handle: "@lecircle",
  lastReviewed: "14 October 2026",
  aiEndpoint: "" // optional: URL of your AI proxy (see worker/ai-proxy.js). Empty means the built in assistant answers on its own.
};

(function () {
  "use strict";
  var doc = document;
  var $ = function (s, r) { return (r || doc).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || doc).querySelectorAll(s)); };

  var groupLinks = {
    main: CONFIG.whatsappMain,
    starters: CONFIG.whatsappStarters,
    builders: CONFIG.whatsappBuilders,
    earners: CONFIG.whatsappEarners
  };
  var adminDigits = String(CONFIG.adminNumber).replace(/\D/g, "");

  function adminLink(text) {
    return "https://wa.me/" + adminDigits + (text ? "?text=" + encodeURIComponent(text) : "");
  }

  /* Fill links and text from CONFIG */
  $$("[data-wa]").forEach(function (a) {
    var url = groupLinks[a.getAttribute("data-wa")];
    if (url) { a.setAttribute("href", url); a.setAttribute("target", "_blank"); a.setAttribute("rel", "noopener"); }
  });
  $$("[data-admin-msg]").forEach(function (a) {
    a.setAttribute("href", adminLink(a.getAttribute("data-admin-msg")));
    a.setAttribute("target", "_blank"); a.setAttribute("rel", "noopener");
  });
  $$("[data-email]").forEach(function (a) {
    var subject = a.getAttribute("data-subject");
    a.setAttribute("href", "mailto:" + CONFIG.email + (subject ? "?subject=" + encodeURIComponent(subject) : ""));
    if (a.hasAttribute("data-email-text")) { a.textContent = CONFIG.email; }
  });
  $$("[data-handle]").forEach(function (el) { el.textContent = CONFIG.handle; });
  $$("[data-social]").forEach(function (a) {
    var h = CONFIG.handle.replace(/^@/, "");
    if (h.charAt(0) !== "[") { a.setAttribute("href", a.getAttribute("data-social") + encodeURIComponent(h)); }
  });
  $$("[data-reviewed]").forEach(function (el) { el.textContent = CONFIG.lastReviewed; });
  $$("[data-admin-text]").forEach(function (el) { el.textContent = "+" + adminDigits; });
  $$("[data-admin-wa]").forEach(function (a) {
    a.setAttribute("href", adminLink("Hi LEC admin"));
    a.setAttribute("target", "_blank"); a.setAttribute("rel", "noopener");
  });
  $$("[data-telegram]").forEach(function (a) {
    if (CONFIG.telegramLink) {
      a.setAttribute("href", CONFIG.telegramLink);
      a.removeAttribute("aria-disabled");
      a.textContent = "Join on Telegram";
    }
  });

  /* Copy buttons */
  function fallbackCopy(text) {
    var t = doc.createElement("textarea");
    t.value = text; t.setAttribute("readonly", "");
    t.style.position = "fixed"; t.style.opacity = "0";
    doc.body.appendChild(t); t.select();
    var ok = false;
    try { ok = doc.execCommand("copy"); } catch (e) { ok = false; }
    doc.body.removeChild(t);
    return ok;
  }
  $$("[data-copy]").forEach(function (btn) {
    btn.addEventListener("click", function () {
      var src = doc.getElementById(btn.getAttribute("data-copy"));
      if (!src) { return; }
      var text = src.innerText || src.textContent;
      var status = btn.parentNode.querySelector(".copied");
      function done(ok) {
        if (status) {
          status.textContent = ok ? "Copied" : "Press and hold the text to copy";
          setTimeout(function () { status.textContent = ""; }, 2500);
        }
      }
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(text).then(function () { done(true); }, function () { done(fallbackCopy(text)); });
      } else { done(fallbackCopy(text)); }
    });
  });

  /* Rate calculator (no live rate API, the exchange rate is yours to edit) */
  var calc = $("#rate-calc");
  if (calc) {
    var fmt = function (n, d) { return n.toLocaleString("en-NG", { maximumFractionDigits: d, minimumFractionDigits: d }); };
    var run = function () {
      var income = parseFloat($("#c-income").value);
      var hours = parseFloat($("#c-hours").value);
      var bill = parseFloat($("#c-bill").value);
      var fx = parseFloat($("#c-fx").value);
      var out = $("#c-out");
      var err = $("#c-err");
      if (!(income > 0) || !(hours > 0) || !(bill > 0 && bill <= 100) || !(fx > 0)) {
        out.hidden = true;
        err.textContent = "Fill every box with a number above zero. Billable time must be between 1 and 100 percent.";
        return;
      }
      err.textContent = "";
      var billableHours = hours * 4.33 * (bill / 100);
      var ngn = income / billableHours;
      $("#r-ngn").textContent = "₦" + fmt(ngn, 0);
      $("#r-usd").textContent = "$" + fmt(ngn / fx, 2);
      $("#r-hrs").textContent = fmt(billableHours, 1);
      out.hidden = false;
    };
    calc.addEventListener("submit", function (e) { e.preventDefault(); run(); });
    calc.addEventListener("input", function () { if (!$("#c-out").hidden) { run(); } });
  }

  /* Level finder quiz */
  var quiz = $("#level-quiz");
  if (quiz) {
    var names = { starters: "LEC Starters", builders: "LEC Builders", earners: "LEC Earners" };
    var why = {
      starters: "You are at the start, and that is a good place to be. Starters helps you pick one skill and finish a first practice project.",
      builders: "You have something to build on. Builders helps you turn it into a portfolio and proof that clients can trust.",
      earners: "You are ready for clients. Earners helps you find them, price your work, and get paid properly."
    };
    quiz.addEventListener("submit", function (e) {
      e.preventDefault();
      var v = function (n) { var c = quiz.querySelector("input[name=" + n + "]:checked"); return c ? c.value : ""; };
      var skill = v("q1"), paid = v("q2"), need = v("q3");
      var box = $("#quiz-result");
      if (!skill || !paid || !need) {
        $("#quiz-err").textContent = "Please answer all three questions.";
        return;
      }
      $("#quiz-err").textContent = "";
      var level;
      if (skill === "no" || need === "learn") { level = "starters"; }
      else if (need === "portfolio") { level = "builders"; }
      else if (skill === "little" && paid === "no") { level = "builders"; }
      else { level = "earners"; }
      var link = groupLinks[level];
      $("#quiz-title").textContent = "Your path: " + names[level];
      $("#quiz-why").textContent = why[level];
      var go = $("#quiz-go");
      go.setAttribute("href", link);
      go.setAttribute("target", "_blank");
      go.setAttribute("rel", "noopener");
      go.textContent = "Open " + names[level] + " on WhatsApp";
      box.hidden = false;
      box.scrollIntoView({ behavior: "smooth", block: "nearest" });
      go.focus();
      try { window.open(link, "_blank", "noopener"); } catch (err) { /* button is the fallback */ }
    });
  }

  /* Intro form, opens WhatsApp with a prefilled message. Nothing is stored. */
  var intro = $("#intro-form");
  if (intro) {
    intro.addEventListener("submit", function (e) {
      e.preventDefault();
      var g = function (id) { return ($("#" + id).value || "").trim(); };
      var msg = "Hi LEC admin, I would like to join.\n" +
        "Name: " + g("f-name") + "\n" +
        "WhatsApp number: " + g("f-num") + "\n" +
        "Country: " + g("f-country") + "\n" +
        "Skill interest: " + g("f-skill") + "\n" +
        "Level: " + g("f-level");
      window.open(adminLink(msg), "_blank", "noopener");
    });
  }

  /* Theme toggle (remembers the choice, falls back to the device setting) */
  var root = doc.documentElement;
  function setTheme(t) {
    root.setAttribute("data-theme", t);
    try { localStorage.setItem("lec-theme", t); } catch (e) { /* private mode */ }
    var m = $('meta[name="theme-color"]'); if (m) { m.setAttribute("content", t === "dark" ? "#06142A" : "#0B2545"); }
    $$("[data-theme-btn]").forEach(function (b) { b.setAttribute("aria-pressed", t === "dark"); });
    window.dispatchEvent(new Event("lec-theme"));
  }
  $$("[data-theme-btn]").forEach(function (b) {
    b.setAttribute("aria-pressed", root.getAttribute("data-theme") === "dark");
    b.addEventListener("click", function () { setTheme(root.getAttribute("data-theme") === "dark" ? "light" : "dark"); });
  });

  /* Mobile menu */
  var mb = $("[data-menu-btn]"), nav = $(".nav");
  if (mb && nav) {
    var closeMenu = function () { nav.classList.remove("open"); mb.setAttribute("aria-expanded", "false"); };
    mb.addEventListener("click", function () {
      var o = nav.classList.toggle("open"); mb.setAttribute("aria-expanded", o ? "true" : "false");
    });
    nav.addEventListener("click", function (e) { if (e.target.closest("a")) { closeMenu(); } });
    doc.addEventListener("keydown", function (e) { if (e.key === "Escape") { closeMenu(); } });
  }

  /* Installable app + offline shell */
  if ("serviceWorker" in navigator && (location.protocol === "https:" || location.hostname === "localhost")) {
    window.addEventListener("load", function () { navigator.serviceWorker.register("sw.js").catch(function () {}); });
  }

  /* Year in footer */
  $$("[data-year]").forEach(function (el) { el.textContent = new Date().getFullYear(); });
})();
