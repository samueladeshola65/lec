/* OPTIONAL: turns the LEC Assistant into a real AI chatbot.
   Deploy this as a Cloudflare Worker (free tier is enough), add your key as a secret named ANTHROPIC_API_KEY,
   then paste the Worker URL into CONFIG.aiEndpoint in main.js. The key never goes in the website files.
   Until you do this, the assistant answers from the site's own content and needs no server. */
const SYSTEM = `You are the LEC Assistant for Learn & Earn Circle (LEC), a free community for Africans, starting with Nigeria, who learn tech and digital skills and turn them into income.
Rules: answer in short, plain, friendly English. Never promise or estimate income. Never give financial, tax or legal advice; say that and point to the Get Paid Toolkit page (toolkit.html) and current provider terms.
LEC is free to join and never asks for money, bank details or passwords. Groups: Starters (beginners), Builders (portfolio and proof), Earners (clients, pricing, getting paid). WhatsApp now, Telegram later.
If you do not know, say so and suggest messaging an admin. Do not invent facts, members, wins, prices or fees. Never write dashes in your replies.`;
const ALLOWED_ORIGINS = ["https://YOUR-DOMAIN.com"]; // set your real domain
export default {
  async fetch(req, env) {
    const origin = req.headers.get("Origin") || "";
    const cors = { "Access-Control-Allow-Origin": ALLOWED_ORIGINS.includes(origin) ? origin : ALLOWED_ORIGINS[0], "Access-Control-Allow-Headers": "Content-Type", "Access-Control-Allow-Methods": "POST, OPTIONS" };
    if (req.method === "OPTIONS") return new Response(null, { headers: cors });
    if (req.method !== "POST") return new Response("Method not allowed", { status: 405, headers: cors });
    let body; try { body = await req.json(); } catch { return new Response("Bad request", { status: 400, headers: cors }); }
    const msg = String(body.message || "").slice(0, 400);
    const hist = (Array.isArray(body.history) ? body.history : []).slice(-6).map(h => ({ role: h.w === "me" ? "user" : "assistant", content: String(h.t || "").slice(0, 500) }));
    const messages = hist.concat([{ role: "user", content: msg }]);
    const r = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: { "content-type": "application/json", "x-api-key": env.ANTHROPIC_API_KEY, "anthropic-version": "2023-06-01" },
      body: JSON.stringify({ model: "claude-haiku-5-5", max_tokens: 300, system: SYSTEM, messages })
    });
    if (!r.ok) return new Response(JSON.stringify({ reply: null }), { headers: { ...cors, "Content-Type": "application/json" } });
    const j = await r.json();
    const reply = (j.content && j.content[0] && j.content[0].text) || null;
    return new Response(JSON.stringify({ reply }), { headers: { ...cors, "Content-Type": "application/json" } });
  }
};
