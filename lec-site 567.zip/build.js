// Generator for the four LEC pages. Run: node build.js
// The shared header, footer and icon sprite live here so the four pages stay identical.
const fs = require("fs");
const path = require("path");

const SITE = "https://example.com/"; // replace with your real domain, see README

const pages = {};

function wordmark(p, cls) {
  return `<svg class="${cls || ""}" viewBox="0 0 420 140" role="img" aria-label="LEC wordmark" xmlns="http://www.w3.org/2000/svg">
<defs>
<g id="${p}l"><path d="M0 0H40V94H110V130H0Z"/><path d="M125 0H222V32H165V49H212V81H165V98H222V130H125Z"/><path d="M336 34.8A47 47 0 1 0 336 95.2" fill="none" stroke-width="36"/></g>
<clipPath id="${p}t"><polygon points="-20,-20 440,-20 440,50 -20,72"/></clipPath>
<clipPath id="${p}b"><polygon points="-20,77 440,55 440,160 -20,160"/></clipPath>
</defs>
<g clip-path="url(#${p}b)" class="wb"><use href="#${p}l"/></g>
<g transform="translate(-4 -4)"><g clip-path="url(#${p}t)" fill="#38B6FF" stroke="#38B6FF"><use href="#${p}l"/></g></g>
<g fill="none" stroke="#38B6FF" stroke-width="5" stroke-linecap="round"><path class="ln" d="M350 58Q384 52 392 26"/><path class="ln" d="M350 74Q394 68 404 50"/><path class="ln" d="M350 90Q398 88 410 76"/></g>
<g fill="#2ECC71"><circle class="nd" cx="392" cy="20" r="9"/><circle class="nd" cx="404" cy="44" r="7.5"/><circle class="nd" cx="410" cy="70" r="7.5"/></g>
</svg>`;
}

const sprite = `<svg width="0" height="0" style="position:absolute" aria-hidden="true" focusable="false"><defs>
<symbol id="i-check" viewBox="0 0 24 24"><path d="M5 12.5l4.5 4.5L19 7.5"/></symbol>
<symbol id="i-x" viewBox="0 0 24 24"><path d="M6 6l12 12M18 6L6 18"/></symbol>
<symbol id="i-book" viewBox="0 0 24 24"><path d="M4 5.5A2.5 2.5 0 0 1 6.500 3H20v15H6.500A2.500 2.500 0 0 0 4 20.500z"/><path d="M4 20.500A2.500 2.500 0 0 0 6.500 23H20v-5"/></symbol>
<symbol id="i-build" viewBox="0 0 24 24"><path d="M3 21l8-8"/><path d="M13.500 4.500l6 6-3 3-6-6z"/><path d="M10.500 7.500L8 5"/></symbol>
<symbol id="i-coin" viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M12 7v10M9.500 14.500c0 1 1.100 1.700 2.500 1.700s2.500-.7 2.500-1.800c0-2.500-5-1.300-5-3.800 0-1 1.100-1.800 2.500-1.800s2.500.7 2.500 1.700"/></symbol>
<symbol id="i-wa" viewBox="0 0 24 24"><path d="M12 3a9 9 0 0 0-7.800 13.500L3 21l4.600-1.200A9 9 0 1 0 12 3z"/><path d="M9 8.500c.3 2.500 2.700 5 6 6l1.200-1.400-2-1-1 .8c-.9-.4-1.700-1.200-2.100-2.100l.8-1-1-2z" fill="currentColor" stroke="none"/></symbol>
<symbol id="i-shield" viewBox="0 0 24 24"><path d="M12 3l8 3v6c0 4.500-3.300 8-8 9-4.700-1-8-4.500-8-9V6z"/><path d="M8.500 12l2.500 2.500 4.500-5"/></symbol>
<symbol id="i-alert" viewBox="0 0 24 24"><path d="M12 3l10 18H2z"/><path d="M12 10v5M12 18v.1"/></symbol>
<symbol id="i-copy" viewBox="0 0 24 24"><rect x="8" y="8" width="12" height="12" rx="2"/><path d="M16 8V6a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h2"/></symbol>
<symbol id="i-users" viewBox="0 0 24 24"><circle cx="9" cy="8" r="3.500"/><path d="M2.500 20c0-3.500 3-6 6.500-6s6.500 2.500 6.500 6"/><circle cx="17.500" cy="9" r="2.500"/><path d="M17 14c2.700 0 4.500 2 4.500 5"/></symbol>
<symbol id="i-heart" viewBox="0 0 24 24"><path d="M12 20s-8-4.800-8-10.500A4.500 4.500 0 0 1 12 7a4.500 4.500 0 0 1 8 2.500C20 15.200 12 20 12 20z"/></symbol>
<symbol id="i-pin" viewBox="0 0 24 24"><path d="M12 22s7-6 7-12a7 7 0 0 0-14 0c0 6 7 12 7 12z"/><circle cx="12" cy="10" r="2.500"/></symbol>
<symbol id="i-net" viewBox="0 0 24 24"><circle cx="5" cy="12" r="2"/><circle cx="19" cy="5" r="2"/><circle cx="19" cy="19" r="2"/><path d="M7 12l10-6M7 12l10 6"/></symbol>
<symbol id="i-spark" viewBox="0 0 24 24"><path d="M12 3l1.9 5.6L19.500 10.500l-5.600 1.900L12 18l-1.900-5.600L4.500 10.500l5.600-1.900z"/><path d="M19 3v4M17 5h4"/></symbol>
<symbol id="i-send" viewBox="0 0 24 24"><path d="M4 12l16-8-6 17-3-7z"/></symbol>
<symbol id="i-sun" viewBox="0 0 24 24"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M2 12h2M20 12h2M5 5l1.500 1.500M17.500 17.500L19 19M5 19l1.500-1.500M17.500 6.500L19 5"/></symbol>
<symbol id="i-moon" viewBox="0 0 24 24"><path d="M20 14.500A8 8 0 0 1 9.500 4 8 8 0 1 0 20 14.500z"/></symbol>
<symbol id="i-menu" viewBox="0 0 24 24"><path d="M4 7h16M4 12h16M4 17h16"/></symbol>
<symbol id="i-chev-l" viewBox="0 0 24 24"><path d="M15 5l-7 7 7 7"/></symbol>
<symbol id="i-chev-r" viewBox="0 0 24 24"><path d="M9 5l7 7-7 7"/></symbol>
<symbol id="i-pause" viewBox="0 0 24 24"><path d="M8 5v14M16 5v14"/></symbol>
<symbol id="i-play" viewBox="0 0 24 24"><path d="M8 5l11 7-11 7z"/></symbol>
<symbol id="i-mail" viewBox="0 0 24 24"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 7l9 6 9-6"/></symbol>
</defs></svg>`;

function icon(name, extra) {
  return `<svg class="icon${extra ? " " + extra : ""}" aria-hidden="true"><use href="#i-${name}"/></svg>`;
}

const favicon = "data:image/svg+xml,%3Csvg xmlns=%27http://www.w3.org/2000/svg%27 viewBox=%270 0 32 32%27%3E%3Crect width=%2732%27 height=%2732%27 rx=%277%27 fill=%27%230B2545%27/%3E%3Crect x=%277%27 y=%277%27 width=%276%27 height=%2712%27 fill=%27%2338B6FF%27/%3E%3Crect x=%277%27 y=%2721%27 width=%2718%27 height=%274%27 fill=%27%23fff%27/%3E%3Ccircle cx=%2725%27 cy=%277%27 r=%273%27 fill=%27%232ECC71%27/%3E%3C/svg%3E";

function head(file, title, desc) {
  const ld = {
    "@context": "https://schema.org",
    "@type": "Organization",
    name: "Learn & Earn Circle",
    alternateName: "LEC",
    url: SITE,
    logo: SITE + "assets/logo.webp",
    description: "A free community for Africans, starting with Nigeria, who want to learn tech and digital skills and turn them into real income.",
    areaServed: "NG",
    sameAs: []
  };
  return `<!doctype html>
<html lang="en" class="no-js">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>${title}</title>
<meta name="description" content="${desc}">
<meta name="theme-color" content="#0B2545">
<meta name="color-scheme" content="light dark">
<link rel="manifest" href="manifest.webmanifest">
<link rel="apple-touch-icon" href="assets/icon-180.png">
<meta property="og:type" content="website">
<meta property="og:site_name" content="Learn &amp; Earn Circle">
<meta property="og:title" content="${title}">
<meta property="og:description" content="${desc}">
<meta property="og:url" content="${SITE}${file === "index.html" ? "" : file}">
<meta property="og:image" content="${SITE}assets/og.png">
<meta property="og:image:width" content="1200">
<meta property="og:image:height" content="630">
<meta name="twitter:card" content="summary_large_image">
<link rel="icon" href="${favicon}">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&family=Plus+Jakarta+Sans:wght@600;700;800&display=swap">
<script>try{var t=localStorage.getItem("lec-theme")||(matchMedia("(prefers-color-scheme: dark)").matches?"dark":"light");document.documentElement.setAttribute("data-theme",t);if(t==="dark"){var m=document.querySelector('meta[name=theme-color]');m&&m.setAttribute("content","#06142A")}}catch(e){}</script>
<link rel="stylesheet" href="styles.css">
<script>document.documentElement.className=document.documentElement.className.replace("no-js","js")</script>
<script type="application/ld+json">${JSON.stringify(ld)}</script>
</head>`;
}

function header(active) {
  const a = (f, label) => `<a href="${f}"${active === f ? ' aria-current="page"' : ""}>${label}</a>`;
  return `<body>
${sprite}
<div class="aurora" aria-hidden="true"><i></i><i></i><i></i></div><canvas id="bg" aria-hidden="true"></canvas><div class="grain" aria-hidden="true"></div><div class="progress" aria-hidden="true"></div>
<a class="skip" href="#main">Skip to content</a>
<header class="site-header">
<div class="wrap bar">
<a class="brand" href="index.html" aria-label="LEC home">${wordmark("h" + active.replace(/\W/g, ""))}</a>
<div class="tools">
<nav class="nav" id="nav" aria-label="Main">
${a("index.html", "Home")}${a("paths.html", "Paths")}${a("toolkit.html", "Toolkit")}<a class="btn btn-green btn-sm" href="join.html"${active === "join.html" ? ' aria-current="page"' : ""}>Join free</a>
</nav>
<button class="icon-btn js-only" type="button" data-theme-btn aria-label="Switch between light and dark mode" aria-pressed="false">${icon("moon", "i-moon")}${icon("sun", "i-sun")}</button>
<button class="icon-btn menu-btn js-only" type="button" data-menu-btn aria-label="Menu" aria-expanded="false" aria-controls="nav">${icon("menu")}</button>
</div>
</div>
</header>`;
}

function footer() {
  const soc = (name, base) => `<li><a data-social="${base}" href="${base}">${name} <span data-handle>[handle]</span></a></li>`;
  return `<footer class="site-footer">
<div class="wrap foot-grid">
<div>
<h3>Learn &amp; Earn Circle</h3>
<p>A free community for Africans, starting with Nigeria, learning tech and digital skills and turning them into income. We never promise income.</p>
<p class="small">Information on this site is not financial or legal advice. LEC is not affiliated with any payment provider or marketplace named here.</p>
</div>
<div>
<h3>Explore</h3>
<ul>
<li><a href="index.html">Home</a></li>
<li><a href="paths.html">Paths</a></li>
<li><a href="toolkit.html">Get Paid Toolkit</a></li>
<li><a href="join.html">Join</a></li>
</ul>
</div>
<div>
<h3>Follow LEC</h3>
<ul>
${soc("Instagram", "https://instagram.com/")}
${soc("X", "https://x.com/")}
${soc("YouTube", "https://youtube.com/@")}
${soc("TikTok", "https://tiktok.com/@")}
${soc("LinkedIn", "https://linkedin.com/company/")}
</ul>
</div>
</div>
<div class="wrap"><p class="small" style="margin-top:1.5rem">&copy; <span data-year>2026</span> Learn &amp; Earn Circle. Telegram coming soon. Handle: <span data-handle>@lecircle</span></p></div>
</footer>
<a class="fab" data-wa="main" href="https://chat.whatsapp.com/REPLACE_MAIN" aria-label="Chat with LEC on WhatsApp">${icon("wa")}</a>
<script src="main.js" defer></script>
<script src="fx.js" defer></script>
<script src="chat.js" defer></script>
</body>
</html>`;
}

function page(file, title, desc, body) {
  const out = head(file, title, desc) + "\n" + header(file) + "\n<main id=\"main\">\n" + body + "\n</main>\n" + footer();
  fs.writeFileSync(path.join(__dirname, file), out);
}

const WA = {
  main: "https://chat.whatsapp.com/REPLACE_MAIN",
  starters: "https://chat.whatsapp.com/REPLACE_STARTERS",
  builders: "https://chat.whatsapp.com/REPLACE_BUILDERS",
  earners: "https://chat.whatsapp.com/REPLACE_EARNERS"
};
const waBtn = (k, label, cls) => `<a class="btn ${cls || "btn-green"}" data-wa="${k}" href="${WA[k]}" target="_blank" rel="noopener">${icon("wa")} ${label}</a>`;
const photo = (file, alt, w, h, cls, eager) => `<figure class="photo ${cls || ""}"><img src="assets/photos/${file}.webp" width="${w}" height="${h}" alt="${alt}"${eager ? ' fetchpriority="high"' : ' loading="lazy"'} decoding="async"></figure>`;
const SLIDES = [
  ["Learn together", "Two young Africans reviewing work together on a laptop in a bright office"],
  ["Build real skills", "A smiling developer looking back from his desk with code on the screen"],
  ["Learn at your pace", "A smiling young woman taking notes beside her laptop"],
  ["Build proof people trust", "A young woman designing on a graphics tablet beside a sunny window"],
  ["Practise every week", "A young man typing at a desk in a busy tech office"],
  ["Earn from your skills", "A smiling man in a blue blazer checking his phone outdoors"]
];
const slider = `<div class="slider" data-slider role="region" aria-roledescription="carousel" aria-label="LEC in pictures">
<div class="slides">
${SLIDES.map((sl, i) => `<figure class="slide${i === 0 ? " is-active" : ""}" role="group" aria-roledescription="slide" aria-label="${i + 1} of ${SLIDES.length}"><img src="assets/photos/slide-${i + 1}.webp" srcset="assets/photos/slide-${i + 1}-sm.webp 640w, assets/photos/slide-${i + 1}.webp 1200w" sizes="(max-width: 859px) 92vw, 540px" width="1200" height="900" alt="${sl[1]}"${i === 0 ? ' fetchpriority="high"' : ' loading="lazy"'} decoding="async"><figcaption>${sl[0]}</figcaption></figure>`).join("\n")}
</div>
<div class="s-bars js-only" aria-label="Choose a slide">${SLIDES.map((sl, i) => `<button type="button" class="s-bar${i === 0 ? " on" : ""}" aria-label="Show slide ${i + 1}: ${sl[0]}"><i></i></button>`).join("")}</div>
<button type="button" class="s-nav prev js-only" aria-label="Previous slide"><svg class="icon" aria-hidden="true"><use href="#i-chev-l"/></svg></button>
<button type="button" class="s-nav next js-only" aria-label="Next slide"><svg class="icon" aria-hidden="true"><use href="#i-chev-r"/></svg></button>
<button type="button" class="s-pause js-only" aria-label="Pause slideshow" aria-pressed="false"><svg class="icon i-pause" aria-hidden="true"><use href="#i-pause"/></svg><svg class="icon i-play" aria-hidden="true"><use href="#i-play"/></svg></button>
</div>`;
const PH = {
  hero: ["hero", "Two young Africans reviewing work together on a laptop in a bright office", 1200, 900],
  learn: ["learn", "A young woman and man learning together over a laptop", 800, 600],
  build: ["build", "A young woman designing on a graphics tablet beside a sunny window", 800, 600],
  earn: ["earn", "A smiling man in a blue blazer checking his phone outdoors", 800, 600],
  community: ["community", "A group of young Africans laughing together around a computer", 900, 900]
};
const ph = (k, cls, eager) => photo(PH[k][0], PH[k][1], PH[k][2], PH[k][3], cls, eager);
const tick = (t) => `<li>${icon("check")}<span>${t}</span></li>`;


const scenePhone = `<div class="scene" aria-hidden="true"><svg viewBox="0 0 240 130"><rect x="84" y="6" width="72" height="118" rx="12" class="s-card s-stroke"/><rect x="96" y="22" width="40" height="14" rx="7" class="s-sky bub"/><rect x="108" y="44" width="40" height="14" rx="7" class="s-green bub"/><rect x="96" y="66" width="46" height="14" rx="7" class="s-sky bub"/><rect x="96" y="92" width="30" height="12" rx="6" class="s-line"/><circle cx="44" cy="40" r="14" class="s-sky" opacity=".5"/><circle cx="200" cy="82" r="14" class="s-green" opacity=".5"/><circle cx="196" cy="30" r="9" class="s-sky" opacity=".35"/><circle cx="36" cy="96" r="9" class="s-green" opacity=".35"/></svg></div>`;
const sceneLaptop = `<div class="scene" aria-hidden="true"><svg viewBox="0 0 240 130"><rect x="46" y="14" width="148" height="88" rx="8" class="s-card s-stroke"/><rect x="58" y="28" width="60" height="7" rx="3" class="s-sky"/><rect x="70" y="42" width="84" height="7" rx="3" class="s-green"/><rect x="70" y="56" width="48" height="7" rx="3" class="s-ink" opacity=".35"/><rect x="58" y="70" width="72" height="7" rx="3" class="s-sky"/><rect x="134" y="70" width="8" height="12" class="s-green cur"/><path d="M26 108h188l-10 12H36z" class="s-ink" opacity=".85"/></svg></div>`;
const sceneCoins = `<div class="scene" aria-hidden="true"><svg viewBox="0 0 240 130"><g class="coin"><circle cx="76" cy="62" r="34" class="s-green"/><text x="76" y="74" text-anchor="middle" font-size="34" font-weight="800" class="s-txt">&#8358;</text></g><g class="coin coin2"><circle cx="168" cy="62" r="34" class="s-sky"/><text x="168" y="74" text-anchor="middle" font-size="34" font-weight="800" class="s-txt">$</text></g><path d="M116 62h8" class="s-stroke" stroke-dasharray="3 5" fill="none" stroke-width="3" stroke-linecap="round"/></svg></div>`;


const heroPic = (n, alt, chips) => `<div class="hero-visual phv"><figure class="photo hero-photo"><img src="assets/photos/hero-${n}.webp" srcset="assets/photos/hero-${n}-sm.webp 640w, assets/photos/hero-${n}.webp 1200w" sizes="(max-width: 859px) 92vw, 520px" width="1200" height="900" alt="${alt}" fetchpriority="high" decoding="async"></figure>${chips}</div>`;

/* ============================== HOME ============================== */
page("index.html",
  "LEC | Learn tech skills and earn from freelancing in Nigeria",
  "Learn & Earn Circle is a free community for Africans, starting with Nigeria, to learn tech skills, build proof, and monetize your skills in naira or dollars.",
`<section class="hero">
<div class="wrap hero-grid">
<div>
<span class="pill"><span class="dot"></span> Free community, starting in Nigeria</span>
<h1 style="margin-top:1rem">Learn a skill. <span class="grad">Earn from it.</span> Together.</h1>
<p class="lead">Learn <span class="rot" data-words="web design|video editing|AI tools|graphic design|copywriting|digital marketing|virtual assistance">web design</span> and turn it into income, in naira or dollars. Honest practice, real people, no hype.</p>
<div class="btn-row">
${waBtn("main", "Join on WhatsApp")}
<a class="btn btn-line" href="join.html#level-finder">Find my path</a>
</div>
<p class="note" style="margin-top:.9rem">Telegram coming soon.</p>
</div>
<div class="hero-visual">
${slider}
<div class="circuit">
<div class="cc-head"><span class="dot"></span> Skill growth circuit</div>
${wordmark("hero", "wm")}
<div class="track" aria-hidden="true"><i></i></div>
<ol class="stages">
<li>Learn<small>Starters</small></li>
<li>Build<small>Builders</small></li>
<li>Earn<small>Earners</small></li>
</ol>
</div>
<span class="float-chip a" aria-hidden="true">Web design</span>
<span class="float-chip b" aria-hidden="true"><b>&#9679;</b> Naira lane</span>
<span class="float-chip c" aria-hidden="true"><b>&#9679;</b> Dollar lane</span>
</div>
</div>
</section>

<section class="trust" aria-label="Why people trust LEC">
<div class="wrap"><ul>
<li>${icon("check")} Free to join</li>
<li>${icon("check")} No get rich quick promises</li>
<li>${icon("check")} Real people</li>
<li>${icon("check")} Real practice</li>
</ul></div>
</section>

<div class="marquee" aria-label="Skills we cover"><div class="mq" aria-hidden="true">${["Web design","AI tools","Video editing","Graphic design","Copywriting","Digital marketing","Virtual assistance","Spreadsheets and data","No code apps"].concat(["Web design","AI tools","Video editing","Graphic design","Copywriting","Digital marketing","Virtual assistance","Spreadsheets and data","No code apps"]).map((x) => `<span>${x}</span>`).join("")}</div></div>

<section>
<div class="wrap">
<h2 class="slice">Three problems we keep seeing</h2>
<div class="grid c3">
<div class="card"><h3>Skills without clients</h3><p>You finished the course. Now nobody knows you exist, and you are not sure where to start looking.</p><div class="solution"><b>LEC solution.</b> Builders helps you create proof and a profile people can trust.</div></div>
<div class="card"><h3>Clients without a way to get paid</h3><p>Someone wants your work, then you get stuck on pricing, invoices, and how to receive the money.</p><div class="solution"><b>LEC solution.</b> The Get Paid Toolkit covers pricing, invoices, and payment options.</div></div>
<div class="card"><h3>Hype without honesty</h3><p>Loud promises about fast money fill your feed. Few people tell you how long it really takes.</p><div class="solution"><b>LEC solution.</b> Honest guidance, no income promises, and a Wins Wall of real wins only.</div></div>
</div>
<p style="margin-top:1.2rem;font-weight:700">LEC fixes this with a simple ladder: Learn, Build, Earn.</p>
</div>
</section>

<div class="divider" aria-hidden="true"></div>

<section class="sec-white" id="how">
<div class="wrap">
<h2 class="slice">How it works</h2>
<p class="lead">Three steps, three subgroups. Start where you are.</p>
<div class="grid c3">
<div class="card">${ph("learn", "card-photo")}<div class="ico-badge">${icon("book")}</div><h3>1. Learn</h3><p><strong>Outcome:</strong> you pick one skill and finish a first practice project.</p><a class="text-link" href="paths.html#starters">LEC Starters</a><div class="stage-track"><i style="--w:33%"></i></div></div>
<div class="card">${ph("build", "card-photo")}<div class="ico-badge">${icon("build")}</div><h3>2. Build</h3><p><strong>Outcome:</strong> you have a portfolio and a profile that show what you can do.</p><a class="text-link" href="paths.html#builders">LEC Builders</a><div class="stage-track"><i style="--w:66%"></i></div></div>
<div class="card">${ph("earn", "card-photo")}<div class="ico-badge green">${icon("coin")}</div><h3>3. Earn</h3><p><strong>Outcome:</strong> you pitch clients, price your work, and get paid safely.</p><a class="text-link" href="paths.html#earners">LEC Earners</a><div class="stage-track"><i style="--w:100%"></i></div></div>
</div>
</div>
</section>

<section>
<div class="wrap split">
${ph("community", "band-photo")}
<div>
<h2 class="slice">Real people, practising together</h2>
<p class="lead">Skills grow faster with company. LEC is built around people who practise, share feedback, and talk honestly about money.</p>
<ul class="ticks">
${tick("Weekly practice tasks you can finish")}
${tick("Feedback from people at your level and above")}
${tick("Straight talk about pricing, clients, and getting paid")}
</ul>
<div class="btn-row">${waBtn("main", "Join the circle")}<a class="btn btn-line" href="paths.html">See the paths</a></div>
<p class="note" style="margin-top:1rem">Photos on this site are for illustration and show models, not LEC members.</p>
</div>
</div>
</section>

<section>
<div class="wrap">
<h2 class="slice">Two income lanes</h2>
<p class="lead">You can use one lane or both. Many people start local, then add global clients.</p>
<div class="grid c2">
<div class="card"><span class="tag green">Paid in naira</span><h3 style="margin-top:.6rem">Local clients</h3>
<p>Shops, schools, churches, creators, and small businesses near you often need simple digital help.</p>
<p>How it works: find a business with a clear need, offer one simple service, agree the price, and get paid by bank transfer or a payment link.</p>
<a class="text-link" href="toolkit.html#local">See local payment options</a></div>
<div class="card"><span class="tag green">Paid in dollars</span><h3 style="margin-top:.6rem">Global clients</h3>
<p>Remote teams, agencies, and people on freelance marketplaces hire across borders every day.</p>
<p>How it works: build a clear profile, send focused proposals, agree the scope, and receive money through an international payment option.</p>
<a class="text-link" href="toolkit.html#international">See international payment options</a></div>
</div>
</div>
</section>

<section class="sec-white">
<div class="wrap">
<h2 class="slice">Skills we cover</h2>
<ul class="chips">
<li>Web design</li><li>AI tools and automation</li><li>Video editing</li><li>Graphic design</li><li>Content and copywriting</li><li>Digital marketing</li><li>Virtual assistance</li><li>Spreadsheets and data</li><li>No code apps</li>
</ul>
<p class="note">Remote and freelance teams hire for these skills across borders. Demand is not a promise of income, but it shows where to look.</p>
</div>
</section>

<section id="blueprint">
<div class="wrap split">
<div>
<h2 class="slice">Your first 30 days</h2>
<ol class="steps">
<li><strong>Week 1</strong>Pick one skill and one place to learn it.</li>
<li><strong>Week 2</strong>Finish a practice project, even a small one.</li>
<li><strong>Week 3</strong>Build a portfolio page and a profile.</li>
<li><strong>Week 4</strong>Pitch your first client.</li>
</ol>
<p class="note" style="margin-top:1rem">Some people move faster, some slower. Both are fine.</p>
</div>
<div class="hero-visual phv trainv">
<figure class="photo hero-photo"><img src="assets/photos/train.webp" srcset="assets/photos/train-sm.webp 640w, assets/photos/train.webp 1000w" sizes="(max-width: 859px) 92vw, 520px" width="1000" height="750" alt="A trainer guiding students through a task on a laptop in a classroom" loading="lazy" decoding="async"></figure>
<span class="float-chip a"><b>Guided</b> practice</span>
<div class="plan-card" aria-hidden="true"><b>30 day plan</b><span class="dots"><i class="on"></i><i></i><i></i><i></i></span><small>Week 1 of 4</small></div>
</div>
</div>
</section>

<section class="sec-white">
<div class="wrap">
<h2 class="slice">Wins wall</h2>
<div class="empty">
<strong>Member wins will appear here</strong>
<p>When members share real wins, with their permission, you will see them here.</p>
<a class="btn btn-dark btn-sm" data-admin-msg="Hi LEC admin, I would like to submit a win." href="https://wa.me/234XXXXXXXXXX?text=Hi%20LEC%20admin%2C%20I%20would%20like%20to%20submit%20a%20win.">Submit a win</a>
</div>
</div>
</section>

<section>
<div class="wrap">
<h2 class="slice">A note from the founder</h2>
<div class="card">
<p><strong>[Founder name and role]</strong></p>
<p>Many people across Nigeria and Africa work hard to learn digital skills, but the step from learning to earning is rarely explained in plain words. LEC exists to explain it, and to do the practice together. We cannot promise you income. We can promise honest guidance, real practice, and people who want to see you get paid.</p>
<p class="note">[Optional proof line, real credentials only]</p>
</div>
</div>
</section>

<section class="dark" id="never">
<div class="wrap">
<h2 class="slice">What we will never do</h2>
<ul class="crosses">
<li>${icon("x")}<span>Promise you income</span></li>
<li>${icon("x")}<span>Charge you to enter</span></li>
<li>${icon("x")}<span>Ask for your bank details or passwords</span></li>
<li>${icon("x")}<span>Run investment or crypto pitches</span></li>
<li>${icon("x")}<span>Sell member data</span></li>
</ul>
</div>
</section>

<section id="faq">
<div class="wrap">
<h2 class="slice">Questions people ask</h2>
<details class="faq"><summary>Is it really free?</summary><div class="ans">Yes. Joining LEC and being part of the community is free, and we will never charge you to enter. Some tools or courses you choose outside LEC may have their own costs, and we will be clear about that.</div></details>
<details class="faq"><summary>Do I need a laptop?</summary><div class="ans">Not to start. You can begin learning, planning, and practising on a phone. A laptop helps for skills like web design and video editing, and you can plan for one as you grow.</div></details>
<details class="faq"><summary>Can I join with no skill?</summary><div class="ans">Yes. LEC Starters is made for you. You will pick one skill and practise it with others who are starting too.</div></details>
<details class="faq"><summary>How do I get paid in Nigeria?</summary><div class="ans">Common ways are bank transfer, payment links from tools like Paystack and Flutterwave, and Selar for digital products. See the <a href="toolkit.html#local">Get Paid Toolkit</a>. Rules and fees change, so always check current terms.</div></details>
<details class="faq"><summary>Is this a scam?</summary><div class="ans">No. We do not ask for money to join, we never ask for bank details or passwords, and we do not promise income. If anyone using the LEC name asks you for money, please report it to the admins. Read <a href="#never">what we will never do</a>.</div></details>
<details class="faq"><summary>WhatsApp or Telegram?</summary><div class="ans">WhatsApp now, Telegram later. It is the same community, so use the app you prefer once Telegram is open. Telegram is coming soon.</div></details>
</div>
</section>

<section class="cta">
<div class="wrap">
<h2>Ready to take the next step?</h2>
<p class="lead">Join the circle. It takes under a minute and it is free.</p>
<div class="btn-row">
${waBtn("main", "Join on WhatsApp")}
<a class="btn btn-line" href="join.html#level-finder">Find my path</a>
<button class="btn btn-line js-only" type="button" data-open-chat>${icon("spark")} Ask the assistant</button>
</div>
</div>
</section>`);

/* ============================== PATHS ============================== */
function pathSection(id, tagName, who, gets, plan, key, btn) {
  return `<section${id === "builders" ? ' class="sec-white"' : ""} id="${id}">
<div class="wrap">
<span class="tag">${tagName}</span>
<h2 class="slice" style="margin-top:.6rem">${tagName === "Level 1" ? "LEC Starters" : tagName === "Level 2" ? "LEC Builders" : "LEC Earners"}</h2>
${photo(id === "starters" ? "learn-wide" : id === "builders" ? "build-wide" : "earn-wide", PH[id === "starters" ? "learn" : id === "builders" ? "build" : "earn"][1], 1200, 400, "wide-photo")}
<div class="grid c2">
<div class="card"><h3>Who it is for</h3><p>${who}</p><h3 style="margin-top:1rem">What you get</h3><ul class="ticks">${gets.map(tick).join("")}</ul></div>
<div class="card"><h3>Your first 30 days</h3><ol class="steps">${plan.map((p, i) => `<li><strong>Week ${i + 1}</strong>${p}</li>`).join("")}</ol></div>
</div>
<div class="btn-row">${waBtn(key, btn)}</div>
</div>
</section>`;
}

page("paths.html",
  "LEC Paths | Starters, Builders and Earners",
  "Pick your LEC path: Starters for beginners, Builders for portfolios and proof, Earners for clients and getting paid. Learn tech skills and monetize your skills.",
`<section class="hero phero">
<div class="wrap hero-grid">
<div>
<span class="pill"><span class="dot"></span> Three paths, one circle</span>
<h1 style="margin-top:1rem">Pick the path that <span class="grad">fits you today</span></h1>
<p class="lead">LEC has three subgroups. You are not stuck in one. Many members start in Starters, move to Builders, then grow into Earners.</p>
<ol class="mini-path" aria-label="The three paths">
<li><b>1</b> Starters<small>Learn</small></li><li><b>2</b> Builders<small>Prove</small></li><li><b>3</b> Earners<small>Get paid</small></li>
</ol>
<div class="btn-row">
<a class="btn btn-primary" href="join.html#level-finder">Find my path ${icon("send")}</a>
${waBtn("main", "Join on WhatsApp")}
</div>
<ul class="mini-trust"><li>${icon("check")} Free to join</li><li>${icon("check")} Real people, real practice</li><li>${icon("check")} No income promises</li></ul>
</div>
${heroPic("paths", "A woman coaching a colleague as they work together on a laptop in a bright office", `<span class="float-chip a"><b>Learn</b> together</span><span class="float-chip b">Move up <b>when ready</b></span>`)}
</div>
</section>
${pathSection("starters", "Level 1",
  "Beginners who want to learn a first skill, or who have just started and feel lost.",
  ["Help picking one skill that fits your time and goals", "Weekly practice tasks you can finish", "Study partners and a friendly place to ask questions", "Feedback on your first practice project"],
  ["Pick one skill and one place to learn it.", "Learn the basics and finish a small practice project.", "Improve the project and share it for feedback.", "Write down what you learned and decide if you are ready for Builders."],
  "starters", "Join LEC Starters")}
${pathSection("builders", "Level 2",
  "People who have a skill and need a portfolio and proof that clients can trust.",
  ["Portfolio reviews from people at your level and above", "Guidance on case studies and profile writing", "Practice briefs that look like real client work", "Accountability for finishing and publishing your work"],
  ["List what you can already do and choose three pieces to show.", "Build or polish one strong case study.", "Set up a portfolio page and a profile on a platform.", "Ask for honest feedback and fix what is unclear."],
  "builders", "Join LEC Builders")}
${pathSection("earners", "Level 3",
  "People who are ready to find clients, price their work, and get paid.",
  ["Pitch practice and message reviews", "Help with pricing, proposals, and agreements", "Guidance on local and international payment options", "A circle that shares lessons from real jobs, good and bad"],
  ["Choose one service and one type of client.", "Set your rate with the calculator and write a proposal.", "Send focused pitches and follow up kindly.", "Agree the scope, send an invoice, and get paid safely."],
  "earners", "Join LEC Earners")}
<section>
<div class="wrap">
<h2 class="slice">Compare the levels</h2>
<div class="table-wrap"><table>
<thead><tr><th scope="col">Level</th><th scope="col">Goal</th><th scope="col">Weekly rhythm</th></tr></thead>
<tbody>
<tr><th scope="row">Starters</th><td>Learn one skill and finish a practice project</td><td>A few short study sessions and one practice task</td></tr>
<tr><th scope="row">Builders</th><td>Build a portfolio and profile that show proof</td><td>Work on one project, share it, and review others</td></tr>
<tr><th scope="row">Earners</th><td>Win clients, price work, and get paid</td><td>Pitch, follow up, deliver, and share one lesson</td></tr>
</tbody></table></div>
<p style="margin-top:1rem">Still unsure? <a class="text-link" href="join.html#level-finder">Take the 3 question level finder</a>.</p>
</div>
</section>`);

/* ============================== TOOLKIT ============================== */
const tpl = (id, title, text) => `<div class="card" style="margin-bottom:16px">
<div class="tpl-head"><h3 style="margin:0">${title}</h3><span><button class="btn btn-dark btn-sm js-only" type="button" data-copy="${id}">${icon("copy")} Copy</button><span class="copied" role="status" aria-live="polite"></span></span></div>
<pre class="tpl" id="${id}">${text}</pre></div>`;

const prov = (name, used, watch) => `<div class="card"><h3>${name}</h3><p><strong>Commonly used for:</strong> ${used}</p><p><strong>Watch out for:</strong> ${watch}</p></div>`;

page("toolkit.html",
  "Get Paid Toolkit | LEC",
  "Everything you need to get paid as a freelancer in Nigeria: find your first client, price your work, local and international payment options, scam safety, and templates.",
`<section class="hero phero">
<div class="wrap">
<div class="hero-grid">
<div>
<span class="pill"><span class="dot"></span> Free toolkit, updated <span data-reviewed>13 October 2026</span></span>
<h1 style="margin-top:1rem">The Get Paid <span class="grad">Toolkit</span></h1>
<p class="lead">Everything you need to get paid, from first client to first withdrawal. Plain steps, templates you can copy, and scam checks.</p>
<div class="btn-row">
<a class="btn btn-primary" href="#client">Find your first client ${icon("send")}</a>
<a class="btn btn-line" href="#templates">Copy a template</a>
</div>
<ul class="mini-trust"><li>${icon("check")} Naira and dollar options</li><li>${icon("check")} Scam safety</li><li>${icon("check")} Ready to copy</li></ul>
</div>
${heroPic("toolkit", "A young professional on a phone call while checking her client paperwork", `<span class="float-chip a">Invoice <b>sent</b></span><span class="float-chip b">Paid, <b>safely</b></span>`)}
</div>
<div class="notice" style="margin-top:28px"><strong>Please read.</strong> Information only, not financial or legal advice. LEC is not affiliated with any provider named here. Rules and fees change, so always check current terms.</div>
<ul class="sub-nav" aria-label="Toolkit sections">
<li><a href="#client">First client</a></li><li><a href="#price">Price your work</a></li><li><a href="#local">Get paid, local</a></li><li><a href="#international">Get paid, international</a></li><li><a href="#safe">Stay safe</a></li><li><a href="#templates">Templates</a></li>
</ul>
</div>
</section>

<section id="client">
<div class="wrap">
<h2 class="slice">1. Find your first client</h2>
<p class="lead">Start with a small number of places and show up properly in each.</p>
<div class="grid c3">
<div class="card"><h3>Upwork and Fiverr</h3><p>Marketplaces where clients post work or browse services. Good for building a track record. Expect competition, so be specific about what you offer.</p></div>
<div class="card"><h3>LinkedIn</h3><p>Share what you are learning and building, then message people who hire for your skill. Be polite and short.</p></div>
<div class="card"><h3>Local businesses</h3><p>Look at businesses near you with weak or missing social pages, menus, flyers, or websites. Offer one simple fix.</p></div>
<div class="card"><h3>Referrals</h3><p>Tell friends, family, and past classmates exactly what you do. People can only refer what they understand.</p></div>
</div>
<h3 style="margin-top:1.6rem">Three message templates</h3>
${tpl("t-local", "Local business message", "Hello [Name], my name is [Your name]. I help small businesses with [service, for example a simple website or social media posts].\n\nI noticed [one specific thing about their business]. I have a short idea that could help with [problem]. Can I send it to you here?\n\nThank you for your time.")}
${tpl("t-online", "Online client message", "Hello [Name], I read your post about [project]. I can help you get [specific result].\n\nHere is a similar piece I made: [link].\n\nMy plan: first [step one], then [step two], then [step three]. I can start on [date].\n\nWould you like a short call, or should I send the plan by message?")}
${tpl("t-ref", "Referral request", "Hi [Name], I now take on [service] work and I am looking for my first few clients.\n\nDo you know a business, a creator, or a team that needs help with [problem]? If you can introduce me, I will send a short note you can forward.\n\nThank you so much!")}
</div>
</section>

<section class="sec-white" id="price">
<div class="wrap">
<h2 class="slice">2. Price your work</h2>
<p class="lead">Work out the lowest hourly rate that still meets your income goal.</p>
<form id="rate-calc" class="card js-only" novalidate>
<div class="field"><label for="c-income">Target monthly income (naira)</label><input id="c-income" type="number" inputmode="numeric" min="1" value="300000"></div>
<div class="field"><label for="c-hours">Working hours per week</label><input id="c-hours" type="number" inputmode="decimal" min="1" max="100" value="30"></div>
<div class="field"><label for="c-bill">Percent of time that is billable</label><input id="c-bill" type="number" inputmode="decimal" min="1" max="100" value="50"><p class="help">Time spent on pitching, learning, and admin is not billable. Half is common when you are starting.</p></div>
<div class="field"><label for="c-fx">Exchange rate (naira for 1 US dollar)</label><input id="c-fx" type="number" inputmode="decimal" min="1" value="1500"><p class="help">This is an example. Change it to the current rate. This page does not fetch live rates.</p></div>
<button class="btn btn-dark" type="submit">Work out my rate</button>
<p id="c-err" role="alert" class="help" style="color:#8A1C1C"></p>
<div id="c-out" class="result-box" hidden>
<p style="margin:0">Your minimum hourly rate</p>
<div class="out-grid" style="margin-top:.6rem">
<div class="card"><div class="big-num" id="r-ngn"></div><div class="note">per hour, naira</div></div>
<div class="card"><div class="big-num" id="r-usd"></div><div class="note">per hour, dollars</div></div>
</div>
<p class="note" style="margin:.8rem 0 0">Based on <span id="r-hrs"></span> billable hours a month. This is a floor, not a target. Add room for tax, tools, slow months, and your growing skill.</p>
</div>
</form>
<div class="card nojs"><p>The calculator needs JavaScript. The formula is: monthly target divided by (hours per week x 4.33 x billable share). Use the same formula with your exchange rate for dollars.</p></div>
</div>
</section>

<section id="local">
<div class="wrap">
<h2 class="slice">3. Get paid, local</h2>
<div class="grid c3">
<div class="card"><h3>Bank transfer</h3><p>The simplest way to be paid by local clients. Share your account name and number in an invoice, and confirm the money has arrived before you deliver final files.</p></div>
<div class="card"><h3>Paystack and Flutterwave payment links</h3><p>Tools that let you send a link so clients can pay by card or transfer. You usually need to set up and verify an account first. Check current terms.</p></div>
<div class="card"><h3>Selar</h3><p>A place to sell digital products such as templates, guides, and courses, and to collect payment for them. Check current terms.</p></div>
</div>
</div>
</section>

<section class="sec-white" id="international">
<div class="wrap">
<h2 class="slice">4. Get paid, international</h2>
<p class="note">These are listed together in no order of preference. We do not state fees, and no option is best for everyone. Check each provider's current terms and what is available in your situation.</p>
<div class="grid c2" style="margin-top:1rem">
${prov("Payoneer", "Receiving payments from international clients and marketplaces, then moving money to a local bank account.", "Verification steps, withdrawal rules, and the exchange rate you actually get. Read the current terms first.")}
${prov("Grey", "Getting account details for receiving money from clients abroad, and converting to naira.", "Which currencies and features are open to you, and the checks needed before you can receive.")}
${prov("Raenest", "Freelancers who want a multi currency account for receiving from clients abroad.", "Limits and features can depend on your verification level. Compare the rate on the day.")}
${prov("Cleva", "Receiving in different currencies and managing money across currencies.", "Which account types and features are available to you, and what documents are required.")}
${prov("Wise", "Moving money between currencies and being paid by clients in countries it supports.", "Availability for people living in Nigeria can differ by feature. Check what you can open and receive before telling a client to pay there.")}
</div>
</div>
</section>

<section id="safe">
<div class="wrap">
<h2 class="slice">5. Stay safe</h2>
<p class="lead">Most scams look friendly. These are the red flags to know.</p>
<div class="grid c2">
<div class="card flag"><h3>${icon("alert")} Paying to get a job</h3><p>Real clients do not ask you to pay for a job, a test kit, or a training before you start.</p></div>
<div class="card flag"><h3>${icon("alert")} Overpayment tricks</h3><p>"I paid too much, please send back the difference." Do not. The first payment can fail or be reversed after you send money.</p></div>
<div class="card flag"><h3>${icon("alert")} Requests for your card or password</h3><p>Never share card details, passwords, or one time codes. A client never needs them to pay you.</p></div>
<div class="card flag"><h3>${icon("alert")} Offers that are too good to be true</h3><p>High pay for very little work, instant hiring with no questions, or pressure to move the chat away from the platform fast.</p></div>
</div>
<div class="btn-row">
<a class="btn btn-dark" data-email data-subject="Scam report" href="mailto:hello@example.com?subject=Scam%20report">${icon("mail")} Report a scam</a>
<a class="btn btn-line" data-admin-wa href="https://wa.me/234XXXXXXXXXX">Message an admin on WhatsApp</a>
</div>
<p class="note">Also report it on the platform where it happened.</p>
</div>
</section>

<section class="sec-white" id="templates">
<div class="wrap">
<h2 class="slice">6. Templates</h2>
${tpl("t-proposal", "Proposal", "Hello [Client name],\n\nThank you for sharing your project.\n\nWhat I understand: [one or two lines about the goal].\nWhat I will deliver: [list of deliverables].\nTimeline: [number] days, starting [date].\nPrice: [amount and currency], with [deposit amount] to start.\nWhat I need from you: [content, access, feedback times].\n\nIf this looks right, reply YES and I will send an invoice for the deposit.\n\nThank you,\n[Your name]")}
${tpl("t-invoice", "Invoice basics", "Include on every invoice:\n\n1. Your name or business name and contact details\n2. Client name and contact details\n3. Invoice number and date\n4. Description of each item and its price\n5. Total amount and currency\n6. Payment method and account details\n7. Due date\n8. A short thank you")}
${tpl("t-agree", "Agreement checklist", "Before you start, agree on and write down:\n\n1. What exactly you will deliver\n2. The price and the currency\n3. Deposit and when the balance is due\n4. How many rounds of changes are included\n5. The deadline and what the client must send you\n6. Who owns the final work and when\n7. How either side can stop the project\n8. Where you will talk, and who decides")}
${tpl("t-follow", "Follow up message", "Hi [Name], I hope you are well. I am following up on my message from [day] about [project]. I would still be glad to help with [result]. If now is not a good time, no problem, just let me know and I will check back later. Thank you!")}
</div>
</section>

<section class="cta"><div class="wrap"><h2>Practise this with others</h2><p class="lead">Members share pitches and lessons in the circle.</p><div class="btn-row">${waBtn("main", "Join on WhatsApp")}</div></div></section>`);

/* ============================== JOIN ============================== */
const q = (name, text, opts) => `<fieldset><legend>${text}</legend>${opts.map(([v, l]) => `<label class="opt"><input type="radio" name="${name}" value="${v}"> <span>${l}</span></label>`).join("")}</fieldset>`;

const joinCard = (k, title, text) => `<div class="card"><div class="ico-badge ${k === "earners" ? "green" : ""}">${icon(k === "starters" ? "book" : k === "builders" ? "build" : "coin")}</div><h3>${title}</h3><p>${text}</p>${waBtn(k, "Join on WhatsApp")}</div>`;

page("join.html",
  "Join LEC | Free WhatsApp community for learning and earning",
  "Pick your path and join the Learn & Earn Circle on WhatsApp in under a minute. Take the level finder, read the community rules, and start to monetize your skills.",
`<section class="hero">
<div class="wrap hero-grid">
<div>
<h1>Pick your path and join in under a minute</h1>
<p class="lead">Take the 3 question level finder, or go straight to the group you want.</p>
</div>
${ph("community", "join-photo", true)}
</div>
</section>

<section id="level-finder">
<div class="wrap">
<h2 class="slice">Level finder</h2>
<form id="level-quiz" class="card js-only" novalidate>
${q("q1", "1. Do you have a skill you can show?", [["yes", "Yes, I can show my work"], ["little", "A little, I am still learning"], ["no", "No, not yet"]])}
${q("q2", "2. Have you been paid for it?", [["yes", "Yes, more than once"], ["once", "Once or twice"], ["no", "Not yet"]])}
${q("q3", "3. What do you need most right now?", [["learn", "To learn a skill"], ["portfolio", "A portfolio and proof"], ["clients", "Clients, pricing, and getting paid"]])}
<button class="btn btn-dark" type="submit">Show my path</button>
<p id="quiz-err" role="alert" class="help" style="color:#8A1C1C"></p>
<div id="quiz-result" class="result-box" hidden>
<h3 id="quiz-title"></h3><p id="quiz-why"></p>
<a id="quiz-go" class="btn btn-primary" href="#groups">Open WhatsApp</a>
</div>
</form>
<div class="card nojs"><p>The level finder needs JavaScript. You can pick a group in the cards below. Starters is for beginners, Builders is for people who need a portfolio, and Earners is for people ready to find clients.</p></div>
</div>
</section>

<section class="sec-white" id="groups">
<div class="wrap">
<h2 class="slice">Join a group</h2>
<div class="grid c2">
${joinCard("starters", "LEC Starters", "For beginners learning a first skill.")}
${joinCard("builders", "LEC Builders", "For people with a skill who need a portfolio and proof.")}
${joinCard("earners", "LEC Earners", "For people ready to find clients, price work, and get paid.")}
<div class="card"><div class="ico-badge">${icon("users")}</div><h3>LEC main community</h3><p>Not sure yet? Start in the main community and say hello.</p>${waBtn("main", "Join on WhatsApp")}</div>
<div class="card"><div class="ico-badge">${icon("net")}</div><h3>Telegram <span class="tag">Coming soon</span></h3><p>We will open the same community on Telegram later.</p><a class="btn btn-line" data-telegram aria-disabled="true" href="#groups">Coming soon</a></div>
</div>
</div>
</section>

<section id="rules">
<div class="wrap">
<h2 class="slice">Community rules</h2>
<ol class="rules">
<li>Respect everyone.</li>
<li>No spam.</li>
<li>No investment or crypto pitches.</li>
<li>No pay to join schemes.</li>
<li>Never share personal or financial data.</li>
<li>Share wins and lessons.</li>
<li>No hate or harassment.</li>
<li>Admins have the final say.</li>
</ol>
</div>
</section>

<section class="sec-white" id="intro">
<div class="wrap">
<h2 class="slice">Optional intro form</h2>
<p>Want to say hello to the admin first? Fill this in and WhatsApp will open with your message ready to send. <strong>Nothing is stored on this site.</strong> The details only go into a WhatsApp message that you send yourself.</p>
<form id="intro-form" class="card js-only">
<div class="field"><label for="f-name">Name</label><input id="f-name" type="text" autocomplete="name" required></div>
<div class="field"><label for="f-num">WhatsApp number</label><input id="f-num" type="tel" autocomplete="tel" inputmode="tel" required></div>
<div class="field"><label for="f-country">Country</label><input id="f-country" type="text" autocomplete="country-name" value="Nigeria" required></div>
<div class="field"><label for="f-skill">Skill interest</label><select id="f-skill" required><option>Web design</option><option>AI tools and automation</option><option>Video editing</option><option>Graphic design</option><option>Content and copywriting</option><option>Digital marketing</option><option>Virtual assistance</option><option>Spreadsheets and data</option><option>No code apps</option><option>Not sure yet</option></select></div>
<div class="field"><label for="f-level">Level</label><select id="f-level" required><option>Starter</option><option>Builder</option><option>Earner</option><option>Not sure</option></select></div>
<button class="btn btn-dark" type="submit">${icon("wa")} Open WhatsApp</button>
</form>
<div class="card nojs"><p>The form needs JavaScript. You can message the admin directly instead: <a data-admin-wa href="https://wa.me/234XXXXXXXXXX">open WhatsApp</a>.</p></div>
</div>
</section>

<section id="contact">
<div class="wrap">
<h2 class="slice">Contact</h2>
<ul class="ticks" style="list-style:none;padding:0">
<li>${icon("mail")}<span>Email: <a data-email data-email-text href="mailto:hello@example.com">hello@example.com</a></span></li>
<li>${icon("wa")}<span>Admin on WhatsApp: <a data-admin-wa href="https://wa.me/234XXXXXXXXXX"><span data-admin-text>+234XXXXXXXXXX</span></a></span></li>
<li>${icon("users")}<span>Social handle: <strong data-handle>[handle]</strong></span></li>
</ul>
</div>
</section>`);

console.log("Built 4 pages.");
