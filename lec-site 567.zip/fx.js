/* LEC motion layer: animated circuit background, scroll reveals, word rotator, card spotlight, scroll progress.
   Everything here is decoration. If it fails, the site still works. */
(function () {
  "use strict";
  var doc = document, root = doc.documentElement;
  var reduce = window.matchMedia && matchMedia("(prefers-reduced-motion: reduce)").matches;
  var conn = navigator.connection || {};
  var saver = !!conn.saveData || /(^|-)2g$/.test(conn.effectiveType || "");
  var lowPower = (navigator.deviceMemory && navigator.deviceMemory <= 2) || (navigator.hardwareConcurrency && navigator.hardwareConcurrency <= 2);

  /* If a photo fails to load, the frame shows its drawn fallback instead of a broken image */
  Array.prototype.forEach.call(doc.querySelectorAll(".photo img, .slide img"), function (im) {
    var bad = function () { im.setAttribute("data-failed", ""); };
    im.addEventListener("error", bad);
    if (im.complete && im.naturalWidth === 0 && im.getAttribute("loading") !== "lazy") { bad(); }
  });

  /* Scroll progress and header shadow */
  var bar = doc.querySelector(".progress"), header = doc.querySelector(".site-header"), ticking = false;
  function onScroll() {
    if (ticking) { return; }
    ticking = true;
    requestAnimationFrame(function () {
      var h = root.scrollHeight - innerHeight;
      if (bar) { bar.style.transform = "scaleX(" + (h > 0 ? Math.min(scrollY / h, 1) : 0) + ")"; }
      if (header) { header.classList.toggle("scrolled", scrollY > 8); }
      ticking = false;
    });
  }
  addEventListener("scroll", onScroll, { passive: true }); onScroll();

  /* Scroll reveal */
  var targets = Array.prototype.slice.call(doc.querySelectorAll("main h2, main .lead, .card, .trust li, .chips li, .steps li, .crosses li, .faq, .rules li, .empty, .table-wrap, .scene"));
  if ("IntersectionObserver" in window && !reduce) {
    var io = new IntersectionObserver(function (es) {
      es.forEach(function (e) { if (e.isIntersecting) { e.target.classList.add("in"); io.unobserve(e.target); } });
    }, { threshold: 0.12, rootMargin: "0px 0px -6% 0px" });
    targets.forEach(function (el, i) {
      if (el.closest(".circuit")) { return; }
      el.classList.add("rv");
      el.style.setProperty("--d", ((i % 4) * 0.08) + "s");
      io.observe(el);
    });
  }


  /* Hero slider: segmented progress bars drive the timing. Pauses on hover, focus, hidden tab and swipe. */
  (function () {
    var sl = doc.querySelector("[data-slider]");
    if (!sl) { return; }
    var slides = Array.prototype.slice.call(sl.querySelectorAll(".slide"));
    var bars = Array.prototype.slice.call(sl.querySelectorAll(".s-bar"));
    var pauseBtn = sl.querySelector(".s-pause");
    var cur = 0, userPaused = false, hoverPaused = false;
    var still = reduce || saver;
    if (still) { sl.classList.add("static"); userPaused = true; if (pauseBtn) { pauseBtn.setAttribute("aria-pressed", "true"); pauseBtn.setAttribute("aria-label", "Play slideshow"); } }
    function show(n) {
      cur = (n + slides.length) % slides.length;
      slides.forEach(function (s, i) { s.classList.toggle("is-active", i === cur); s.setAttribute("aria-hidden", i === cur ? "false" : "true"); });
      bars.forEach(function (b, i) {
        b.classList.remove("on"); b.classList.toggle("done", i < cur);
        if (i === cur) { void b.offsetWidth; b.classList.add("on"); b.setAttribute("aria-current", "true"); } else { b.removeAttribute("aria-current"); }
      });
    }
    function syncPause() { sl.classList.toggle("is-paused", userPaused || hoverPaused || doc.hidden); }
    bars.forEach(function (b, i) {
      b.addEventListener("click", function () { show(i); });
      b.addEventListener("animationend", function (e) { if (e.target.parentNode === b || e.target === b.firstChild || b.classList.contains("on")) { show(cur + 1); } }, true);
    });
    var prev = sl.querySelector(".prev"), next = sl.querySelector(".next");
    if (prev) { prev.addEventListener("click", function () { show(cur - 1); }); }
    if (next) { next.addEventListener("click", function () { show(cur + 1); }); }
    if (pauseBtn) {
      pauseBtn.addEventListener("click", function () {
        userPaused = !userPaused;
        pauseBtn.setAttribute("aria-pressed", userPaused ? "true" : "false");
        pauseBtn.setAttribute("aria-label", userPaused ? "Play slideshow" : "Pause slideshow");
        sl.classList.toggle("static", still && userPaused);
        syncPause();
      });
    }
    sl.addEventListener("mouseenter", function () { hoverPaused = true; syncPause(); });
    sl.addEventListener("mouseleave", function () { hoverPaused = false; syncPause(); });
    sl.addEventListener("focusin", function () { hoverPaused = true; syncPause(); });
    sl.addEventListener("focusout", function () { hoverPaused = false; syncPause(); });
    doc.addEventListener("visibilitychange", syncPause);
    sl.addEventListener("keydown", function (e) {
      if (e.key === "ArrowLeft") { show(cur - 1); } else if (e.key === "ArrowRight") { show(cur + 1); }
    });
    // swipe
    var x0 = null;
    sl.addEventListener("pointerdown", function (e) { x0 = e.clientX; });
    sl.addEventListener("pointerup", function (e) {
      if (x0 === null) { return; }
      var dx = e.clientX - x0; x0 = null;
      if (Math.abs(dx) > 40) { show(cur + (dx < 0 ? 1 : -1)); }
    });
    sl.addEventListener("pointercancel", function () { x0 = null; });
    show(0); syncPause();
  })();

  /* Rotating skill word in the hero */
  var rot = doc.querySelector(".rot");
  if (rot && !reduce) {
    var words = (rot.getAttribute("data-words") || "").split("|").filter(Boolean), wi = 0;
    if (words.length > 1) {
      setInterval(function () {
        rot.classList.add("out");
        setTimeout(function () { wi = (wi + 1) % words.length; rot.textContent = words[wi]; rot.classList.remove("out"); }, 350);
      }, 2400);
    }
  }

  /* Card spotlight follows the pointer */
  if (matchMedia("(hover:hover)").matches) {
    doc.addEventListener("pointermove", function (e) {
      var c = e.target.closest && e.target.closest(".card");
      if (!c) { return; }
      var r = c.getBoundingClientRect();
      c.style.setProperty("--mx", (e.clientX - r.left) + "px");
      c.style.setProperty("--my", (e.clientY - r.top) + "px");
    }, { passive: true });
  }

  /* Animated circuit network background */
  var cv = doc.getElementById("bg");
  if (!cv || !cv.getContext || saver || lowPower) { if (cv) { cv.remove(); } return; }
  var ctx = cv.getContext("2d"), W = 0, H = 0, dpr = Math.min(devicePixelRatio || 1, 1.5);
  var nodes = [], pulses = [], mouse = { x: -999, y: -999 }, running = true, raf = 0, last = 0, col = {};
  function readColors() {
    var s = getComputedStyle(root);
    var dark = root.getAttribute("data-theme") === "dark";
    col.line = dark ? "56,182,255" : "11,37,69";
    col.lineA = dark ? 0.2 : 0.12;
    col.node = dark ? "56,182,255" : "11,37,69";
    col.green = "46,204,113";
  }
  function resize() {
    W = innerWidth; H = innerHeight;
    cv.width = W * dpr; cv.height = H * dpr;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    var n = Math.max(22, Math.min(64, Math.round(W * H / 26000)));
    nodes = [];
    for (var i = 0; i < n; i++) {
      nodes.push({ x: Math.random() * W, y: Math.random() * H, vx: (Math.random() - .5) * .22, vy: (Math.random() - .5) * .22, r: 1.4 + Math.random() * 1.8, g: Math.random() < .14 });
    }
  }
  var LINK = 150;
  function frame(t) {
    if (!running) { return; }
    raf = requestAnimationFrame(frame);
    if (t - last < 33) { return; } // about 30 frames a second is plenty and saves battery
    last = t;
    ctx.clearRect(0, 0, W, H);
    var i, j, a, b, dx, dy, d;
    for (i = 0; i < nodes.length; i++) {
      a = nodes[i];
      a.x += a.vx; a.y += a.vy;
      if (a.x < -20) { a.x = W + 20; } else if (a.x > W + 20) { a.x = -20; }
      if (a.y < -20) { a.y = H + 20; } else if (a.y > H + 20) { a.y = -20; }
      dx = a.x - mouse.x; dy = a.y - mouse.y; d = dx * dx + dy * dy;
      if (d < 18000) { a.x += dx * .0016; a.y += dy * .0016; }
    }
    ctx.lineWidth = 1;
    for (i = 0; i < nodes.length; i++) {
      a = nodes[i];
      for (j = i + 1; j < nodes.length; j++) {
        b = nodes[j]; dx = a.x - b.x; dy = a.y - b.y; d = dx * dx + dy * dy;
        if (d < LINK * LINK) {
          var k = 1 - Math.sqrt(d) / LINK;
          var near = (a.x - mouse.x) * (a.x - mouse.x) + (a.y - mouse.y) * (a.y - mouse.y) < 22000;
          ctx.strokeStyle = near ? "rgba(" + col.green + "," + (k * .55) + ")" : "rgba(" + col.line + "," + (k * col.lineA * 2) + ")";
          ctx.beginPath(); ctx.moveTo(a.x, a.y);
          // right angle "circuit trace" look: horizontal then vertical
          ctx.lineTo(b.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke();
        }
      }
    }
    for (i = 0; i < nodes.length; i++) {
      a = nodes[i];
      ctx.fillStyle = a.g ? "rgba(" + col.green + ",.9)" : "rgba(" + col.node + ",.35)";
      ctx.beginPath(); ctx.arc(a.x, a.y, a.g ? a.r + 1.4 : a.r, 0, 6.2832); ctx.fill();
    }
    // earning pulses travel from one node to another along a trace
    if (!pulses.length || (Math.random() < .02 && pulses.length < 3)) {
      var s = nodes[(Math.random() * nodes.length) | 0], e = nodes[(Math.random() * nodes.length) | 0];
      if (s !== e) { pulses.push({ s: s, e: e, p: 0 }); }
    }
    for (i = pulses.length - 1; i >= 0; i--) {
      var q = pulses[i]; q.p += .012;
      if (q.p >= 1) { pulses.splice(i, 1); continue; }
      var px, py, p2 = q.p * 2;
      if (p2 < 1) { px = q.s.x + (q.e.x - q.s.x) * p2; py = q.s.y; } else { px = q.e.x; py = q.s.y + (q.e.y - q.s.y) * (p2 - 1); }
      var gr = ctx.createRadialGradient(px, py, 0, px, py, 14);
      gr.addColorStop(0, "rgba(" + col.green + ",.95)"); gr.addColorStop(1, "rgba(" + col.green + ",0)");
      ctx.fillStyle = gr; ctx.beginPath(); ctx.arc(px, py, 14, 0, 6.2832); ctx.fill();
    }
  }
  function start() { if (!raf && !reduce) { running = true; raf = requestAnimationFrame(frame); } }
  function stop() { running = false; cancelAnimationFrame(raf); raf = 0; }
  readColors(); resize();
  if (reduce) { running = true; frame(100); running = false; } else { start(); }
  var rt; addEventListener("resize", function () { clearTimeout(rt); rt = setTimeout(function () { resize(); if (reduce) { running = true; frame(100); running = false; } }, 200); });
  addEventListener("pointermove", function (e) { mouse.x = e.clientX; mouse.y = e.clientY; }, { passive: true });
  addEventListener("pointerleave", function () { mouse.x = mouse.y = -999; });
  addEventListener("lec-theme", readColors);
  doc.addEventListener("visibilitychange", function () { if (doc.hidden) { stop(); } else { start(); } });
})();
