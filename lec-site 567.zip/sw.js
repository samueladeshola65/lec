/* LEC offline shell. Pages are fetched fresh when online and fall back to the last copy when offline. */
var V = "lec-v6";
var SHELL = ["index.html","paths.html","toolkit.html","join.html","styles.css","main.js","fx.js","chat.js","manifest.webmanifest","assets/icon-192.png"];
self.addEventListener("install", function (e) { e.waitUntil(caches.open(V).then(function (c) { return c.addAll(SHELL); }).then(function () { return self.skipWaiting(); })); });
self.addEventListener("activate", function (e) { e.waitUntil(caches.keys().then(function (ks) { return Promise.all(ks.filter(function (k) { return k !== V; }).map(function (k) { return caches.delete(k); })); }).then(function () { return self.clients.claim(); })); });
self.addEventListener("fetch", function (e) {
  var r = e.request;
  if (r.method !== "GET" || new URL(r.url).origin !== location.origin) { return; }
  e.respondWith(fetch(r).then(function (res) { var copy = res.clone(); caches.open(V).then(function (c) { c.put(r, copy); }); return res; }).catch(function () { return caches.match(r).then(function (m) { return m || caches.match("index.html"); }); }));
});
